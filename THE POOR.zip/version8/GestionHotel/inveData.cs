﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace GestionHotel
{
    internal class inveData
    {
        csConexion conexion = new csConexion();
        public int IdInventario { get; set; }
        public int IdProducto { get; set; }
        public int Cantidad { get; set; }
     
        public string FechaRegistro { get; set; }

        public List<inveData> ListInventario()
        {
            List<inveData> lista = new List<inveData>();
            try { 
            conexion.Abrir();
            string selectData = "SELECT * FROM Inventario";
                using (SqlCommand cmd = new SqlCommand(selectData, conexion.ObtenerConexion()))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        inveData inv = new inveData();
                        inv.IdInventario = (int)reader["id_inventario"];
                        inv.IdProducto = (int)reader["id_producto"];
                        inv.Cantidad = (int)reader["cantidad"];
                      
                        inv.FechaRegistro = reader["fecha_registro"].ToString();
                        lista.Add(inv);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al conectar con la base de datos: " + ex.Message);
            }
            finally
            {
                conexion.Cerrar();
            }
            return lista;
        }
    }
}
