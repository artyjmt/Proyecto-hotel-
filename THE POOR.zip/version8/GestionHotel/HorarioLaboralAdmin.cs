﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionHotel
{
    public partial class HorarioLaboralAdmin : UserControl
    {
        private csConexion conexion = new csConexion();
        private csAñadirUsuario User = new csAñadirUsuario();
        public HorarioLaboralAdmin()
        {
            InitializeComponent();
            CargarEmpleados();
            cmbEmpleado.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            cmbEmpleado.AutoCompleteSource = AutoCompleteSource.ListItems;

            cmbHoraEntrada.DropDownStyle = ComboBoxStyle.DropDown;
            cmbHoraEntrada.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            cmbHoraEntrada.AutoCompleteSource = AutoCompleteSource.ListItems;

            cmbHoraSalida.DropDownStyle = ComboBoxStyle.DropDown;
            cmbHoraSalida.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            cmbHoraSalida.AutoCompleteSource = AutoCompleteSource.ListItems;
        }
        private void CargarEmpleados(string seleccionarUsuario = "")
        {

            try
            {
                DataTable dt = User.ObtenerUsuarios();

                if (dt != null && dt.Rows.Count > 0)
                {
                    cmbEmpleado.DataSource = dt;
                    cmbEmpleado.DisplayMember = "nombre_usuario";   // lo que se muestra en el ComboBox
                    cmbEmpleado.ValueMember = "numero_identificacion"; // valor oculto

                    // 🔹 Selecciona automáticamente el usuario recién añadido si se pasa
                    if (!string.IsNullOrEmpty(seleccionarUsuario))
                    {
                        cmbEmpleado.SelectedIndex = cmbEmpleado.FindStringExact(seleccionarUsuario);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error cargando empleados: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        public void RefreshData()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)RefreshData);
                return;

            }

        }

        private void cmbEmpleado_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbEmpleado.SelectedValue != null)
            {
                txtIdentificacion.Text = cmbEmpleado.SelectedValue.ToString();
            }
        }

        public void RefrescarEmpleados(string usuarioNuevo = "")
        {
            CargarEmpleados(usuarioNuevo);
        }

        private void btnaña_Click(object sender, EventArgs e)
        {

        }
    }
}
