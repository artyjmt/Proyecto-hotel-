﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GestionHotel
{
    public partial class PanelAdministración : UserControl
    {
        private csConexion conexion = new csConexion();
        public PanelAdministración()
        {
            InitializeComponent();
            this.Load += PanelAdministración_Load;
        }
        private Timer refreshTimer;

        private void PanelAdministración_Load(object sender, EventArgs e)
        {
            RefreshData();
            CargarHabitacionesReservadas();

            refreshTimer = new Timer();
            refreshTimer.Interval = 10000; // cada 10 segundos
            refreshTimer.Tick += (s, ev) => RefreshData();
            refreshTimer.Start();
        }

        public void RefreshData()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)RefreshData);
                return;
            }


            ActualizarTotalHabitaciones();
            ActualizarTotalUsuarios(); // Actualiza el label5 con el total de usuarios
        }

        private void ActualizarTotalHabitaciones()
        {
            try
            {
                conexion.Abrir();
                // Contar solo habitaciones activas
                string query = "SELECT COUNT(*) FROM room WHERE status = 'Activo' AND date_delete IS NULL";
                using (SqlCommand cmd = new SqlCommand(query, conexion.ObtenerConexion()))
                {
                    int totalHabitaciones = (int)cmd.ExecuteScalar();
                    label6.Text = totalHabitaciones.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar total de habitaciones: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }

        private void ActualizarTotalUsuarios()
        {
            try
            {
                conexion.Abrir();
                string query = "SELECT COUNT(id) FROM users";
                using (SqlCommand cmd = new SqlCommand(query, conexion.ObtenerConexion()))
                {
                    int totalUsuarios = (int)cmd.ExecuteScalar();
                    label5.Text = $"{totalUsuarios}";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar total de usuarios: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }


        private void label5_Click(object sender, EventArgs e)
        {
            ActualizarTotalUsuarios();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
        public void ActualizarNombreCliente(string nombre)
        {
            label7.Text = nombre;
        }


        public void CargarHabitacionesReservadas()
        {

            try
            {
                conexion.Abrir();
                string query = @"
                SELECT 
                    r.id AS [ID],
                    r.room_id AS [Habitación],
                    r.type AS [Tipo],
                    r.room_name AS [Nombre],
                    r.price AS [Precio],
                    r.status AS [Estado],
                    ISNULL(c.full_name, '') AS [Cliente],
                    c.date_from AS [Desde],
                    c.date_to AS [Hasta]
                FROM room r
                LEFT JOIN customer c ON r.room_id = c.room_id
                WHERE r.date_delete IS NULL
                  AND r.status = 'Ocupado';";   // 🔹 Solo mostrar ocupadas

                SqlDataAdapter da = new SqlDataAdapter(query, conexion.ObtenerConexion());
                DataTable dt = new DataTable();
                da.Fill(dt);

                // 🔹 Ya no necesitas filtrar manualmente (cada habitación ocupada se muestra una vez)
                dataGridView1.AutoGenerateColumns = true;
                dataGridView1.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar habitaciones reservadas: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }


        public void MostrarUltimoNombreCliente()
        {
            try
            {
                conexion.Abrir();
                string query = "SELECT TOP 1 full_name FROM customer ORDER BY id DESC";
                using (SqlCommand cmd = new SqlCommand(query, conexion.ObtenerConexion()))
                {
                    object result = cmd.ExecuteScalar();
                    label7.Text = result != null ? result.ToString() : "Sin reservas";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener el último nombre de cliente: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                label7.Text = "Sin reservas";

            }
            finally
            {
                conexion.Cerrar();
            }
        }
        private decimal totalAcumulado = 0;

        public void AcumularTotal(decimal monto)
        {
            totalAcumulado += monto;
            label7.Text = totalAcumulado.ToString("0.00") + " $";
        }

        public void RegistrarPago(string nombreCliente, string roomID, decimal monto,
                          DateTime fromDate, DateTime toDate)
        {

            try
            {
                conexion.Abrir();

                // Verificar que la habitación esté activa
                string queryCheck = "SELECT status FROM room WHERE room_id=@room_id AND status='Activo'";
                using (SqlCommand cmdCheck = new SqlCommand(queryCheck, conexion.ObtenerConexion()))
                {
                    cmdCheck.Parameters.AddWithValue("@room_id", roomID);
                    object result = cmdCheck.ExecuteScalar();
                    if (result == null) return;
                }

                // Sumar al total
                totalAcumulado += monto;
                label7.Text = totalAcumulado.ToString("0.00") + " $";

                // Guardar en la tabla customer (con fechas incluidas)
                string queryCliente = @"UPDATE customer 
                                    SET room_id=@room_id, 
                                        status_payment='Pagado', 
                                        date_from=@date_from, 
                                        date_to=@date_to,
                                        price=@price
                                    WHERE full_name=@full_name";
                using (SqlCommand cmdCliente = new SqlCommand(queryCliente, conexion.ObtenerConexion()))
                {
                    cmdCliente.Parameters.AddWithValue("@room_id", roomID);
                    cmdCliente.Parameters.AddWithValue("@date_from", fromDate);
                    cmdCliente.Parameters.AddWithValue("@date_to", toDate);
                    cmdCliente.Parameters.AddWithValue("@price", monto);
                    cmdCliente.Parameters.AddWithValue("@full_name", nombreCliente);
                    cmdCliente.ExecuteNonQuery();
                }

                // Cambiar estado de la habitación
                string queryRoom = "UPDATE room SET status='Ocupado' WHERE room_id=@room_id";
                using (SqlCommand cmdRoom = new SqlCommand(queryRoom, conexion.ObtenerConexion()))
                {
                    cmdRoom.Parameters.AddWithValue("@room_id", roomID);
                    cmdRoom.ExecuteNonQuery();
                }


                // Refrescar grilla de habitaciones reservadas
                CargarHabitacionesReservadas();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al registrar pago: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }

        private PanelAdministración panelAdministracion;


        public void SetPanelAdministracion(PanelAdministración panel)
        {
            panelAdministracion = panel;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void PanelAdministración_Load_1(object sender, EventArgs e)
        {

        }
    }
}
