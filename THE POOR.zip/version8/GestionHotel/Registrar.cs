﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace GestionHotel
{
    public partial class Registrar : Form
    {
        public Registrar()
        {
            InitializeComponent();
        }

        private string conn = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Usuario\\Documents\\hotel.mdf;Integrated Security=True;Connect Timeout=30;";
        private void buttonLogin_Click(object sender, EventArgs e)
        {
            if (register_username.Text == "" || confi_cntra.Text == "" || conf_password.Text == "")
            {
                MessageBox.Show("Por favor rellena todos los espacios en blanco", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (confi_cntra.Text != conf_password.Text)
            {
                MessageBox.Show("Lascontraseña no son iguales", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                using (SqlConnection connect = new SqlConnection(conn))
                {
                    connect.Open();

                    string checkUsern = "SELECT username FROM users WHERE username = @usern";
                    using (SqlCommand checkU = new SqlCommand(checkUsern, connect))
                    {
                        checkU.Parameters.AddWithValue("@usern", register_username.Text.Trim());


                        SqlDataAdapter sda = new SqlDataAdapter(checkU);
                        DataTable table = new DataTable();
                        sda.Fill(table);

                        if (table.Rows.Count > 0)
                        {
                            string tempEmail = register_username.Text.Substring(0, 1).ToUpper() + register_username.Text.Substring(1);
                            MessageBox.Show($"{tempEmail} ya existe", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return; // Exit if the username already exists
                        }
                        else if (confi_cntra.Text.Length < 6)
                        {
                            MessageBox.Show("la contreseña debe tener al menos 6 caracteres", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return; // Exit if the username is too short
                        }
                        else if (confi_cntra.Text != conf_password.Text)
                        {
                            MessageBox.Show("Las contraseñas no coinciden", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return; // Exit if the passwords do not match
                        }
                        else
                        {
                            string query = "INSERT INTO users (username, password, role, status, date_register) " +
                                "VALUES (@usern, @pass, @role, @status, @regDate)";
                            using (SqlCommand insertCmd = new SqlCommand(query, connect))
                            {
                                insertCmd.Parameters.AddWithValue("@usern", register_username.Text.Trim());
                                insertCmd.Parameters.AddWithValue("@pass", confi_cntra.Text.Trim());
                                insertCmd.Parameters.AddWithValue("@role", "Staff"); // Default role is 'user'
                                insertCmd.Parameters.AddWithValue("@status", "active"); // Default status is 'active'
                                DateTime today = DateTime.Now; // Current date and time
                                insertCmd.Parameters.AddWithValue("@regDate", today); // Current date and time
                                insertCmd.ExecuteNonQuery();

                                MessageBox.Show("Registration successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                this.Close(); // Close the registration form after successful registration

                                Form1 loginForm = new Form1();
                                loginForm.Show(); // Show the login form
                                this.Hide(); // Hide the registration form
                            }
                        }

                    }
                }
            }
        }

        private void Registrar_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void login_showPass_CheckedChanged(object sender, EventArgs e)
        {
            conf_password.PasswordChar = login_showPass.Checked ? '\0' : '*';
            confi_cntra.PasswordChar = login_showPass.Checked ? '\0' : '*';
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 loginForm = new Form1();
            loginForm.Show();
            this.Hide(); // Hide the registration form when opening the login form
        }
    }
}
