﻿ALTER TABLE users
ADD tipo_identificacion VARCHAR(20) NULL
    CONSTRAINT chk_tipo_identificacion_users 
    CHECK (tipo_identificacion IN ('RUC','Cédula','Pasaporte'));

ALTER TABLE users
ADD numero_identificacion VARCHAR(50) NULL;

select * from users


ALTER TABLE customer
ADD tipo_identificacion VARCHAR(20) NULL
    CONSTRAINT chk_tipo_identificacion_customer
    CHECK (tipo_identificacion IN ('RUC', 'Cédula', 'Pasaporte'));

ALTER TABLE customer
ADD numero_identificacion VARCHAR(50) NULL;


select * from customer