﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace GestionHotel
{
    internal class roomsData
    {
        private csConexion conexion = new csConexion();
        public int ID { get; set; } //0
        public string RoomID { get; set; } //1
        public string RoomType { get; set; } //2
        public string RoomName { get; set; } //3
        public string Price { get; set; }   //4
        public string Image { get; set; } //5
        public string Status { get; set; } //6

        public string Date { get; set; } //7
        public List<roomsData> listRoomsData()
        {
            List<roomsData> listData = new List<roomsData>();
            try { 
                conexion.Abrir();
                string selectData = "SELECT * FROM room WHERE date_delete IS NULL";
                using (SqlCommand cmd = new SqlCommand(selectData, conexion.ObtenerConexion()))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        roomsData rData = new roomsData();
                        rData.ID = (int)reader["id"];
                        rData.RoomID = reader["room_id"].ToString();
                        rData.RoomType = reader["type"].ToString();
                        rData.RoomName = reader["room_name"].ToString();
                        rData.Price = reader["price"].ToString();
                        rData.Image = reader["image_path"].ToString(); // Assuming you want to store the image path
                        rData.Status = reader["status"].ToString();
                        rData.Date = reader["date_register"].ToString();
                        
                        listData.Add(rData);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al conectar con la base de datos: " + ex.Message);
            }
            finally
            {
                conexion.Cerrar();
            }
            return listData;
        }
    }
}
