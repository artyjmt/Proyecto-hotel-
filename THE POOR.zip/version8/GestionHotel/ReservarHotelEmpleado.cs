﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GestionHotel
{
    public partial class ReservarHotelEmpleado : UserControl
    {
        private PanelAdministración PanelAdministración;
        private csConexion conexion = new csConexion();
        private csReservaHotel reservaHotel = new csReservaHotel();

        public ReservarHotelEmpleado()
        {
            InitializeComponent();
            displayRooms();
            this.Load += ReservarHotelEmpleado_Load;
            txtTarjeta.MaxLength = 16;
            bookRoom_from.ValueChanged += (s, e) => CalcularTotal();
            bookRoom_to.ValueChanged += (s, e) => CalcularTotal();

        }
        private void ReservarHotelEmpleado_Load(object sender, EventArgs e)
        {
            CargarClientes();
            ConfigurarBuscador();


        }
        public void SetTextoLabel(string texto)
        {
            label3.Text = texto;
        }

        public void RefreshData()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)RefreshData);
                return;
            }
        }
        public void displayRooms()
        {
            try
            {
                conexion.Abrir();
                string query = "SELECT * FROM room WHERE status = 'Activo'"; // Solo disponibles
                using (SqlCommand cmd = new SqlCommand(query, conexion.ObtenerConexion()))
                {
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);

                    dataGridView1.DataSource = dt;

                    // Si quieres limpiar selección previa
                    dataGridView1.ClearSelection();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar habitaciones: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();

            }
        }

        private int getID = 0;
        private decimal getPrice = 0;
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return; // Evita encabezado
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

            // Validar que la celda no sea nula
            if (row.Cells["id"].Value == null || row.Cells["id"].Value == DBNull.Value) return;

            getID = Convert.ToInt32(row.Cells["id"].Value);
            bookRoom_roomID.Text = row.Cells["room_id"].Value.ToString();
            bookRoom_roomType.Text = row.Cells["type"].Value.ToString();
            bookRoom_roomName.Text = row.Cells["room_name"].Value.ToString();
            bookRoom_status.Text = row.Cells["status"].Value.ToString();
            bookRoom_getPrecio.Text = Convert.ToDecimal(row.Cells["price"].Value).ToString("0.00") + "$";
            getPrice = Convert.ToDecimal(row.Cells["price"].Value);
            bookRoom_imageView.ImageLocation = row.Cells["image_path"].Value.ToString();
        }

        private void CalcularTotal()
        {
            DateTime fromDate = bookRoom_from.Value.Date;
            DateTime toDate = bookRoom_to.Value.Date;

            int days = (toDate - fromDate).Days;

            decimal total = reservaHotel.Calculartotal(days, getPrice);

            bookRoom_total.Text = total.ToString("0.00") + "$";
        }


        private void bookpaga_Btn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textbuscador.Text))
            {
                MessageBox.Show("Debe seleccionar un cliente antes de realizar el pago.",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string nombreCliente = textbuscador.Text.Trim();
            string roomID = bookRoom_roomID.Text.Trim();

            // Tomamos las fechas seleccionadas
            DateTime fromDate = bookRoom_from.Value.Date;
            DateTime toDate = bookRoom_to.Value.Date;

            // Validaciones de fechas
            if (toDate <= fromDate)
            {
                MessageBox.Show("La fecha de salida debe ser posterior a la de entrada.",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Convertimos el texto del total a número
            string totalText = bookRoom_total.Text.Replace("$", "").Replace(",", ".").Trim();

            if (!decimal.TryParse(totalText, System.Globalization.NumberStyles.Any,
                                  System.Globalization.CultureInfo.InvariantCulture, out decimal monto))
            {
                MessageBox.Show("El monto a pagar no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Pasamos todos los datos al PanelAdministración
            PanelAdministración?.RegistrarPago(nombreCliente, roomID, monto, fromDate, toDate);

            MessageBox.Show($"¡Reserva registrada!\nCliente: {nombreCliente}\nHabitación: {roomID}\n" +
                            $"Desde: {fromDate:dd/MM/yyyy}  Hasta: {toDate:dd/MM/yyyy}\n" +
                            $"Total: {monto:0.00}$",
                            "Pago exitoso", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Refrescar habitaciones disponibles
            displayRooms();
        }

        public void SetPanelAdministracion(PanelAdministración panel)
        {
            PanelAdministración = panel;
        }

        private void bookRoom_total_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }



        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void CargarClientes()
        {
            try
            {
                conexion.Abrir();
                string query = "SELECT full_name FROM customer";
                using (SqlCommand cmd = new SqlCommand(query, conexion.ObtenerConexion()))
                {
                    SqlDataReader reader = cmd.ExecuteReader();

                    // Creamos una nueva colección para reemplazar la anterior
                    AutoCompleteStringCollection clientes = new AutoCompleteStringCollection();
                    while (reader.Read())
                    {
                        clientes.Add(reader["full_name"].ToString());
                    }

                    // Asignamos la nueva lista al AutoComplete del TextBox
                    textbuscador.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    textbuscador.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    textbuscador.AutoCompleteCustomSource = clientes;

                    RefreshData(); // Llamamos a RefreshData para actualizar la UI
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar clientes: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }
        public void ConfigurarBuscador()
        {
            try
            {
                conexion.Abrir();
                string query = "SELECT full_name FROM customer";
                using (SqlCommand cmd = new SqlCommand(query, conexion.ObtenerConexion()))
                {
                    SqlDataReader reader = cmd.ExecuteReader();

                    AutoCompleteStringCollection clientes = new AutoCompleteStringCollection();
                    while (reader.Read())
                    {
                        clientes.Add(reader["full_name"].ToString());
                    }

                    // Reinicia AutoComplete del TextBox
                    textbuscador.AutoCompleteCustomSource = null; // eliminar primero
                    textbuscador.AutoCompleteCustomSource = clientes; // reasignar colección
                    textbuscador.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    textbuscador.AutoCompleteSource = AutoCompleteSource.CustomSource;


                    textbuscador.Refresh();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al configurar el buscador: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }

        private void txtTarjeta_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Bloquea el carácter
            }
        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }

        private void textbuscador_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboMetodoPago_SelectedIndexChanged(object sender, EventArgs e)
        {

            // Verificamos qué opción está seleccionada
            string metodo = comboMetodoPago.SelectedItem?.ToString();

            if (metodo == "Efectivo")
            {
                txtTarjeta.Enabled = false;  // Bloquea el TextBox
                txtTarjeta.Text = "";       // Limpia por si acaso
            }
            else if (metodo == "Tarjeta de credito/debito")
            {
                txtTarjeta.Enabled = true;   // Activa el TextBox
            }
        }

        private void txtTarjeta_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

