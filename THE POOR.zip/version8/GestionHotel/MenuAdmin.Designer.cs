﻿namespace GestionHotel
{
    partial class MenuAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.exit = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.login_btn = new System.Windows.Forms.Button();
            this.customers_btn = new System.Windows.Forms.Button();
            this.rooms_btn = new System.Windows.Forms.Button();
            this.addUser_btn = new System.Windows.Forms.Button();
            this.dashboard_btn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            this.panelAdministración1 = new GestionHotel.PanelAdministración();
            this.clientesAdmin1 = new GestionHotel.ClientesAdmin();
            this.alojamientoAdmin1 = new GestionHotel.AlojamientoAdmin();
            this.añadirUsuarioAdmin1 = new GestionHotel.AñadirUsuarioAdmin();
            this.inventarioAdmin1 = new GestionHotel.InventarioAdmin();
            this.horarioLaboralAdmin1 = new GestionHotel.HorarioLaboralAdmin();
            this.pagosAdmin1 = new GestionHotel.PagosAdmin();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MidnightBlue;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.exit);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1669, 48);
            this.panel1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(4, 11);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(341, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "SISTEMA DE GESTION HOTELERA";
            // 
            // exit
            // 
            this.exit.AutoSize = true;
            this.exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit.ForeColor = System.Drawing.Color.White;
            this.exit.Location = new System.Drawing.Point(1629, 11);
            this.exit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(26, 25);
            this.exit.TabIndex = 0;
            this.exit.Text = "X";
            this.exit.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.login_btn);
            this.panel2.Controls.Add(this.customers_btn);
            this.panel2.Controls.Add(this.rooms_btn);
            this.panel2.Controls.Add(this.addUser_btn);
            this.panel2.Controls.Add(this.dashboard_btn);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 48);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(380, 833);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.RoyalBlue;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MidnightBlue;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MidnightBlue;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(47, 629);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(280, 49);
            this.button3.TabIndex = 10;
            this.button3.Text = "PAGO";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.RoyalBlue;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MidnightBlue;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MidnightBlue;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(48, 572);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(280, 49);
            this.button2.TabIndex = 9;
            this.button2.Text = "HORARIO LABORAL";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.RoyalBlue;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MidnightBlue;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MidnightBlue;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(48, 512);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(280, 49);
            this.button1.TabIndex = 8;
            this.button1.Text = "INVENTARIO";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // login_btn
            // 
            this.login_btn.BackColor = System.Drawing.Color.MidnightBlue;
            this.login_btn.FlatAppearance.BorderSize = 0;
            this.login_btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.RoyalBlue;
            this.login_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue;
            this.login_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.login_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.login_btn.ForeColor = System.Drawing.Color.White;
            this.login_btn.Location = new System.Drawing.Point(47, 752);
            this.login_btn.Margin = new System.Windows.Forms.Padding(4);
            this.login_btn.Name = "login_btn";
            this.login_btn.Size = new System.Drawing.Size(280, 49);
            this.login_btn.TabIndex = 7;
            this.login_btn.Text = "Cerrar Sesion";
            this.login_btn.UseVisualStyleBackColor = false;
            this.login_btn.Click += new System.EventHandler(this.login_btn_Click);
            // 
            // customers_btn
            // 
            this.customers_btn.BackColor = System.Drawing.Color.RoyalBlue;
            this.customers_btn.FlatAppearance.BorderSize = 0;
            this.customers_btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MidnightBlue;
            this.customers_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MidnightBlue;
            this.customers_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.customers_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customers_btn.ForeColor = System.Drawing.Color.White;
            this.customers_btn.Location = new System.Drawing.Point(48, 442);
            this.customers_btn.Margin = new System.Windows.Forms.Padding(4);
            this.customers_btn.Name = "customers_btn";
            this.customers_btn.Size = new System.Drawing.Size(280, 49);
            this.customers_btn.TabIndex = 6;
            this.customers_btn.Text = "NOMINA CLIENTES";
            this.customers_btn.UseVisualStyleBackColor = false;
            this.customers_btn.Click += new System.EventHandler(this.customers_btn_Click);
            // 
            // rooms_btn
            // 
            this.rooms_btn.BackColor = System.Drawing.Color.RoyalBlue;
            this.rooms_btn.FlatAppearance.BorderSize = 0;
            this.rooms_btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MidnightBlue;
            this.rooms_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MidnightBlue;
            this.rooms_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rooms_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rooms_btn.ForeColor = System.Drawing.Color.White;
            this.rooms_btn.Location = new System.Drawing.Point(48, 373);
            this.rooms_btn.Margin = new System.Windows.Forms.Padding(4);
            this.rooms_btn.Name = "rooms_btn";
            this.rooms_btn.Size = new System.Drawing.Size(280, 49);
            this.rooms_btn.TabIndex = 5;
            this.rooms_btn.Text = "AÑADIR HABITACIONES";
            this.rooms_btn.UseVisualStyleBackColor = false;
            this.rooms_btn.Click += new System.EventHandler(this.rooms_btn_Click);
            // 
            // addUser_btn
            // 
            this.addUser_btn.BackColor = System.Drawing.Color.RoyalBlue;
            this.addUser_btn.FlatAppearance.BorderSize = 0;
            this.addUser_btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MidnightBlue;
            this.addUser_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MidnightBlue;
            this.addUser_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addUser_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUser_btn.ForeColor = System.Drawing.Color.White;
            this.addUser_btn.Location = new System.Drawing.Point(48, 304);
            this.addUser_btn.Margin = new System.Windows.Forms.Padding(4);
            this.addUser_btn.Name = "addUser_btn";
            this.addUser_btn.Size = new System.Drawing.Size(280, 49);
            this.addUser_btn.TabIndex = 4;
            this.addUser_btn.Text = "AÑADIR USUARIO";
            this.addUser_btn.UseVisualStyleBackColor = false;
            this.addUser_btn.Click += new System.EventHandler(this.addUser_btn_Click);
            // 
            // dashboard_btn
            // 
            this.dashboard_btn.BackColor = System.Drawing.Color.RoyalBlue;
            this.dashboard_btn.FlatAppearance.BorderSize = 0;
            this.dashboard_btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MidnightBlue;
            this.dashboard_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MidnightBlue;
            this.dashboard_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dashboard_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dashboard_btn.ForeColor = System.Drawing.Color.White;
            this.dashboard_btn.Location = new System.Drawing.Point(48, 240);
            this.dashboard_btn.Margin = new System.Windows.Forms.Padding(4);
            this.dashboard_btn.Name = "dashboard_btn";
            this.dashboard_btn.Size = new System.Drawing.Size(280, 49);
            this.dashboard_btn.TabIndex = 3;
            this.dashboard_btn.Text = "PANEL";
            this.dashboard_btn.UseVisualStyleBackColor = false;
            this.dashboard_btn.Click += new System.EventHandler(this.dashboard_btn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(112, 145);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "BIENVENIDO";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GestionHotel.Properties.Resources.LogoHotel;
            this.pictureBox1.Location = new System.Drawing.Point(113, 7);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(148, 134);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panelAdministración1
            // 
            this.panelAdministración1.Location = new System.Drawing.Point(376, 49);
            this.panelAdministración1.Margin = new System.Windows.Forms.Padding(5);
            this.panelAdministración1.Name = "panelAdministración1";
            this.panelAdministración1.Size = new System.Drawing.Size(1289, 832);
            this.panelAdministración1.TabIndex = 5;
            // 
            // clientesAdmin1
            // 
            this.clientesAdmin1.Location = new System.Drawing.Point(376, 49);
            this.clientesAdmin1.Margin = new System.Windows.Forms.Padding(5);
            this.clientesAdmin1.Name = "clientesAdmin1";
            this.clientesAdmin1.Size = new System.Drawing.Size(1289, 832);
            this.clientesAdmin1.TabIndex = 4;
            // 
            // alojamientoAdmin1
            // 
            this.alojamientoAdmin1.Location = new System.Drawing.Point(376, 49);
            this.alojamientoAdmin1.Margin = new System.Windows.Forms.Padding(5);
            this.alojamientoAdmin1.Name = "alojamientoAdmin1";
            this.alojamientoAdmin1.Size = new System.Drawing.Size(1289, 832);
            this.alojamientoAdmin1.TabIndex = 3;
            // 
            // añadirUsuarioAdmin1
            // 
            this.añadirUsuarioAdmin1.Location = new System.Drawing.Point(376, 49);
            this.añadirUsuarioAdmin1.Margin = new System.Windows.Forms.Padding(5);
            this.añadirUsuarioAdmin1.Name = "añadirUsuarioAdmin1";
            this.añadirUsuarioAdmin1.Size = new System.Drawing.Size(1289, 832);
            this.añadirUsuarioAdmin1.TabIndex = 2;
            this.añadirUsuarioAdmin1.Load += new System.EventHandler(this.añadirUsuarioAdmin1_Load);
            // 
            // inventarioAdmin1
            // 
            this.inventarioAdmin1.Location = new System.Drawing.Point(376, 49);
            this.inventarioAdmin1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.inventarioAdmin1.Name = "inventarioAdmin1";
            this.inventarioAdmin1.Size = new System.Drawing.Size(1289, 832);
            this.inventarioAdmin1.TabIndex = 6;
            this.inventarioAdmin1.Load += new System.EventHandler(this.inventarioAdmin1_Load);
            // 
            // horarioLaboralAdmin1
            // 
            this.horarioLaboralAdmin1.Location = new System.Drawing.Point(376, 48);
            this.horarioLaboralAdmin1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.horarioLaboralAdmin1.Name = "horarioLaboralAdmin1";
            this.horarioLaboralAdmin1.Size = new System.Drawing.Size(1289, 833);
            this.horarioLaboralAdmin1.TabIndex = 7;
            this.horarioLaboralAdmin1.Load += new System.EventHandler(this.horarioLaboralAdmin1_Load);
            // 
            // pagosAdmin1
            // 
            this.pagosAdmin1.Location = new System.Drawing.Point(376, 48);
            this.pagosAdmin1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pagosAdmin1.Name = "pagosAdmin1";
            this.pagosAdmin1.Size = new System.Drawing.Size(1289, 829);
            this.pagosAdmin1.TabIndex = 8;
            // 
            // MenuAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1669, 881);
            this.Controls.Add(this.panelAdministración1);
            this.Controls.Add(this.clientesAdmin1);
            this.Controls.Add(this.alojamientoAdmin1);
            this.Controls.Add(this.añadirUsuarioAdmin1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.horarioLaboralAdmin1);
            this.Controls.Add(this.inventarioAdmin1);
            this.Controls.Add(this.pagosAdmin1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MenuAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MenuAdmin";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label exit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button dashboard_btn;
        private System.Windows.Forms.Button customers_btn;
        private System.Windows.Forms.Button rooms_btn;
        private System.Windows.Forms.Button addUser_btn;
        private System.Windows.Forms.Button login_btn;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.ComponentModel.BackgroundWorker backgroundWorker2;
        private AñadirUsuarioAdmin añadirUsuarioAdmin1;
        private AlojamientoAdmin alojamientoAdmin1;
        private ClientesAdmin clientesAdmin1;
        private PanelAdministración panelAdministración1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private InventarioAdmin inventarioAdmin1;
        private HorarioLaboralAdmin horarioLaboralAdmin1;
        private PagosAdmin pagosAdmin1;
    }
}