﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;

namespace GestionHotel
{
    public partial class AñadirClienteEmpleado : UserControl
    {
        private csConexion conexion = new csConexion();
        private ReservarHotelEmpleado reservarHotelForm;
        private csAñadirCliente cliente = new csAñadirCliente();
        public AñadirClienteEmpleado()
        {
            InitializeComponent();
            displayCustomers();
            client_contact.MaxLength = 10;

        }

        public void SetReservarHotelForm(ReservarHotelEmpleado form)
        {
            reservarHotelForm = form;
        }
        public void RefreshData()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)RefreshData);
                return;
            }

        }
        public void displayCustomers()
        {
            try
            {
                conexion.Abrir();
                // ✅ Se quita book_id
                string query = "SELECT id, full_name, email, contact, gender, address, tipo_identificacion, numero_identificacion FROM customer";

                SqlDataAdapter sda = new SqlDataAdapter(query, conexion.ObtenerConexion());
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

            string fullName = client_fullName.Text;
            string email = client_email.Text;
            string contact = client_contact.Text;
            string gender = client_gender.SelectedItem?.ToString() ?? "";
            string address = client_address.Text;
            string tipoIdent = client_tipoIdentificacion.SelectedItem?.ToString();
            string numIdent = client_numIdentificacion.Text;
            if (string.IsNullOrWhiteSpace(tipoIdent))
            {
                MessageBox.Show("Seleccione un tipo de identificación", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                
                cliente.AddCustomer(
                    client_fullName.Text.Trim(),
                    client_email.Text.Trim(),
                    client_contact.Text.Trim(),
                    client_gender.SelectedItem?.ToString() ?? "",
                    client_address.Text.Trim(),
                    client_tipoIdentificacion.SelectedItem?.ToString() ?? "",
                    client_numIdentificacion.Text.Trim()
                );

                MessageBox.Show("Cliente agregado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                displayCustomers();
                ClearFields();

                if (reservarHotelForm != null)
                {
                    reservarHotelForm.CargarClientes();
                    reservarHotelForm.ConfigurarBuscador();
                }
            }
            catch (ArgumentException ex) // validación de campos
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex) // errores generales
            {
                MessageBox.Show("Error al añadir cliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            // Validación según tipo
            string tipo = tipoIdent; // ya seguro que no es null
            string numero = numIdent.Trim();
            // 🔹 Validación según tipo
            if (tipo == "Cédula")
            {
                if (numero.Length != 10 || !numero.All(char.IsDigit))
                {
                    MessageBox.Show("La cédula debe tener exactamente 10 dígitos numéricos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            else if (tipo == "RUC")
            {
                if (numero.Length != 13 || !numero.All(char.IsDigit))
                {
                    MessageBox.Show("El RUC debe tener exactamente 13 dígitos numéricos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            else if (tipo == "Pasaporte")
            {
                if (numero.Length < 8 || numero.Length > 9)
                {
                    MessageBox.Show("El pasaporte debe tener entre 8 y 9 caracteres alfanuméricos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

        }
        private int getID = 0; // Guardará el ID del cliente seleccionado
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                getID = row.Cells["id"].Value is int ? (int)row.Cells["id"].Value : 0;

                client_fullName.Text = row.Cells["full_name"].Value.ToString();
                client_email.Text = row.Cells["email"].Value.ToString();
                client_contact.Text = row.Cells["contact"].Value.ToString();
                client_gender.Text = row.Cells["gender"].Value.ToString();
                client_address.Text = row.Cells["address"].Value.ToString();
                client_tipoIdentificacion.Text = row.Cells["tipo_identificacion"].Value.ToString();
                client_numIdentificacion.Text = row.Cells["numero_identificacion"].Value.ToString();


                // REFRESCAR BUSCADOR
                reservarHotelForm?.ConfigurarBuscador();
            }
        }

        private void btnresesrvar_Click(object sender, EventArgs e)
        {

        }
        private PanelAdministración PanelAdministración;

        public void SetPanelAdministracion(PanelAdministración panel)
        {
            PanelAdministración = panel;
        }

        private void client_contact_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Bloquea el carácter
            }
        }

        private void client_email_Leave(object sender, EventArgs e)
        {
            string email = client_email.Text.Trim();
            if (string.IsNullOrEmpty(email))
                return;
            if (!client_email.Text.Contains("@") || !client_email.Text.Contains("."))
            {
                MessageBox.Show("Correo inválido");
            }
        }

        private void client_contact_TextChanged(object sender, EventArgs e)
        {

        }

        private void btneditar_Click(object sender, EventArgs e)
        {
            if (getID == 0)
            {
                MessageBox.Show("Seleccione un cliente para editar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(client_fullName.Text) ||
                string.IsNullOrWhiteSpace(client_email.Text) ||
                string.IsNullOrWhiteSpace(client_contact.Text) ||
                client_gender.SelectedIndex == -1 ||
                string.IsNullOrWhiteSpace(client_address.Text))
            {
                MessageBox.Show("Complete todos los campos antes de editar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            try
            {
                if (getID == -1)
                {
                    MessageBox.Show("Seleccione un cliente antes de editar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                cliente.EditarCustomer(
                    getID,
                    client_fullName.Text.Trim(),
                    client_email.Text.Trim(),
                    client_contact.Text.Trim(),
                    client_gender.SelectedItem?.ToString() ?? "",
                    client_address.Text.Trim(),
                    client_tipoIdentificacion.SelectedItem?.ToString() ?? "",
                    client_numIdentificacion.Text.Trim()
                );

                MessageBox.Show("Cliente actualizado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                displayCustomers();
                ClearFields();

                // refrescar buscador
                reservarHotelForm?.CargarClientes();
                reservarHotelForm?.ConfigurarBuscador();
            }
            catch (ArgumentException ex) // validación
            {
                MessageBox.Show(ex.Message, "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex) // error general
            {
                MessageBox.Show("Error al actualizar cliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        

        private void client_clearBtn_Click(object sender, EventArgs e)
        {
            client_fullName?.Clear();
            client_email?.Clear();
            client_contact?.Clear();

            if (client_gender != null)
                client_gender.SelectedIndex = -1;

            client_address?.Clear();

            if (client_tipoIdentificacion != null)
                client_tipoIdentificacion.SelectedIndex = -1;

            client_numIdentificacion?.Clear();

            getID = 0;
        }

        private void btneliminar_Click(object sender, EventArgs e)
        {

            if (getID == 0)
            {
                MessageBox.Show("Seleccione un cliente para eliminar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var confirm = MessageBox.Show("¿Está seguro que desea eliminar este cliente?", "Confirmar eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm == DialogResult.Yes)
            {
                try
                {

                    {
                        cliente.DeleteCustomer(getID);

                        MessageBox.Show("Cliente eliminado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        displayCustomers();
                        ClearFields();

                        // refrescar buscador
                        reservarHotelForm?.CargarClientes();
                        reservarHotelForm?.ConfigurarBuscador();

                        getID = -1;
                    }
                }
                catch (ArgumentException ex) // validación
                {
                    MessageBox.Show(ex.Message, "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                catch (Exception ex) // error general
                {
                    MessageBox.Show("Error al eliminar cliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            }

        private void ClearFields()
        {
            client_fullName.Clear();
            client_email.Clear();
            client_contact.Clear();
            client_gender.SelectedIndex = -1;
            client_address.Clear();
            client_tipoIdentificacion.SelectedIndex = -1;
            client_numIdentificacion.Clear();
            getID = 0;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void client_numIdentificacion_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (client_tipoIdentificacion.SelectedItem == null) return;

            string tipo = client_tipoIdentificacion.SelectedItem.ToString();

            if (tipo == "Cédula")
            {
                client_numIdentificacion.MaxLength = 10; // Solo 10 dígitos
            }
            else if (tipo == "RUC")
            {
                client_numIdentificacion.MaxLength = 13; // Solo 13 dígitos
            }
            else if (tipo == "Pasaporte")
            {
                client_numIdentificacion.MaxLength = 9; // Generalmente 8 o 9
            }
        }

        private void client_tipoIdentificacion_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

