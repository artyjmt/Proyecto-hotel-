﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient; // Agrega este using si no está
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionHotel
{
    public partial class ComprasProductos : UserControl
    {
        private csConexion conexion = new csConexion();
        private PanelAdministración panelAdministracion;
        private csCompraProductos gestor = new csCompraProductos();

        public ComprasProductos()
        {
            InitializeComponent();
            RefreshProductosVenta();
            txtTarjeta.MaxLength = 16;
        }

        public void RefreshData()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)RefreshData);
                return;
            }

            // Cadena de conexión igual que en PanelAdministración
            try { 
                conexion.Abrir();
                // Solo los campos solicitados
                string query = "SELECT room_id, type, room_name FROM room WHERE date_delete IS NULL";
                SqlDataAdapter da = new SqlDataAdapter(query, conexion.ObtenerConexion());
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }

        public void RefreshProductosVenta()
        {
            try { 
                conexion.Abrir();
                string query = @"
            SELECT v.id_producto, p.nombre AS nombre_producto, v.cantidad, v.precio, v.image1_path
            FROM ProductosVenta v
            INNER JOIN Productos p ON v.id_producto = p.id_producto";

                SqlDataAdapter da = new SqlDataAdapter(query, conexion.ObtenerConexion());
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView2.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Verifica que el click sea en una fila válida
            if (e.RowIndex >= 0 && dataGridView1.Rows[e.RowIndex].Cells.Count >= 3)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                // Asigna los valores a los TextBox correspondientes
                texthabi.Text = row.Cells["room_id"].Value?.ToString();
                textnaha.Text = row.Cells["type"].Value?.ToString();
                textcli.Text = row.Cells["room_name"].Value?.ToString();
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textnaha_TextChanged(object sender, EventArgs e)
        {

        }

        private void textcli_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dataGridView2.Rows[e.RowIndex].Cells.Count >= 5)
            {
                DataGridViewRow row = dataGridView2.Rows[e.RowIndex];
                textpro.Text = row.Cells["id_producto"].Value?.ToString(); // ✅ ID del producto
                textprono.Text = row.Cells["nombre_producto"].Value?.ToString(); // ✅ Nombre del producto
                textpre.Text = row.Cells["precio"].Value?.ToString();
                textcan.Text = "";

                // Imagen
                var imagePath = row.Cells["image1_path"].Value?.ToString();
                if (!string.IsNullOrEmpty(imagePath) && System.IO.File.Exists(imagePath))
                {
                    ImagePath.Image = Image.FromFile(imagePath);
                }
                else
                {
                    ImagePath.Image = null;
                }
            }
        }

        private void textpro_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Asegúrate de usar los nombres correctos de los TextBox
            decimal precio = 0;
            int cantidad = 0;

            // Intenta obtener el precio y la cantidad desde los TextBox
            decimal.TryParse(textpre.Text, out precio);
            int.TryParse(textcan.Text, out cantidad);

            decimal total = precio * cantidad;
            textpagar.Text = total.ToString("0.00");


        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Quita el símbolo $ y convierte el texto a decimal
            // Validar campos básicos
            if (string.IsNullOrWhiteSpace(textpagar.Text) ||
                string.IsNullOrWhiteSpace(textpro.Text) ||
                string.IsNullOrWhiteSpace(textcan.Text))
            {
                MessageBox.Show("Debe completar todos los campos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Convertir valores
            decimal monto = Convert.ToDecimal(textpagar.Text.Replace("$", "").Trim());
            int idProducto = Convert.ToInt32(textpro.Text);
            int cantidad = Convert.ToInt32(textcan.Text);

            // Procesar pago

            string resultado = gestor.PagoCarrito(idProducto, cantidad, monto);

            if (resultado == "OK")
            {
                panelAdministracion?.AcumularTotal(monto);
                RefreshProductosVenta();
                MessageBox.Show("Pago realizado y stock actualizado.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show(resultado, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        public void SetPanelAdministracion(PanelAdministración panel)
        {
            panelAdministracion = panel;
        }

        private void textcan_TextChanged(object sender, EventArgs e)
        {

        }

        private void textcan_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Bloquea el carácter
            }
        }

        private void txtTarjeta_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Bloquea el carácter
            }
        }

        private void txtTarjeta_TextChanged(object sender, EventArgs e)
        {

        }

        private void textprono_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboMetodoPago_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Verificamos qué opción está seleccionada
            string metodo = comboMetodoPago.SelectedItem?.ToString();

            if (metodo == "Efectivo")
            {
                txtTarjeta.Enabled = false;  // Bloquea el TextBox
                txtTarjeta.Text = "";       // Limpia por si acaso
            }
            else if (metodo == "Tarjeta de credito/debito")
            {
                txtTarjeta.Enabled = true;   // Activa el TextBox
            }
        }
    }
}
