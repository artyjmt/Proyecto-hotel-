﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionHotel
{
    internal class csAñadirCliente
    {
        csConexion conexion = new csConexion();
        public void AddCustomer(string fullName, string email, string contact, string gender, string address, string tipoIdent, string numIdent)
        {
            if (string.IsNullOrWhiteSpace(fullName) ||
                string.IsNullOrWhiteSpace(email) ||
                string.IsNullOrWhiteSpace(contact) ||
                string.IsNullOrWhiteSpace(gender) ||
                string.IsNullOrWhiteSpace(address) ||
                string.IsNullOrWhiteSpace(tipoIdent) ||
                string.IsNullOrWhiteSpace(numIdent))
            {
                throw new ArgumentException("Complete todos los campos antes de agregar un cliente.");
            }

            try
            {
                conexion.Abrir();

                // Validar duplicados
                string checkQuery = "SELECT COUNT(*) FROM customer WHERE full_name=@full_name OR email=@email OR contact=@contact OR numero_identificacion=@numIdent";
                using (SqlCommand checkCmd = new SqlCommand(checkQuery, conexion.ObtenerConexion()))
                {
                    checkCmd.Parameters.AddWithValue("@full_name", fullName);
                    checkCmd.Parameters.AddWithValue("@email", email);
                    checkCmd.Parameters.AddWithValue("@contact", contact);
                    checkCmd.Parameters.AddWithValue("@numIdent", numIdent);

                    int count = Convert.ToInt32(checkCmd.ExecuteScalar());
                    if (count > 0)
                    {
                        throw new Exception("Ya existe un cliente con el mismo nombre, correo, contacto o identificación.");
                    }
                }

                // Insertar cliente
                string query = @"INSERT INTO customer 
                                (full_name, email, contact, gender, address, tipo_identificacion, numero_identificacion) 
                                VALUES (@full_name, @email, @contact, @gender, @address, @tipoIdent, @numIdent)";

                using (SqlCommand cmd = new SqlCommand(query, conexion.ObtenerConexion()))
                {
                    cmd.Parameters.AddWithValue("@full_name", fullName);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@contact", contact);
                    cmd.Parameters.AddWithValue("@gender", gender);
                    cmd.Parameters.AddWithValue("@address", address);
                    cmd.Parameters.AddWithValue("@tipoIdent", tipoIdent);
                    cmd.Parameters.AddWithValue("@numIdent", numIdent);

                    cmd.ExecuteNonQuery();
                }
            }
            finally
            {
                conexion.Cerrar();
            }
        }
        public void EditarCustomer(int id, string fullName, string email, string contact, string gender, string address, string tipoIdent, string numIdent)
        {
            if (id <= 0)
                throw new ArgumentException("Debe seleccionar un cliente válido para editar.");

            if (string.IsNullOrWhiteSpace(fullName) ||
                string.IsNullOrWhiteSpace(email) ||
                string.IsNullOrWhiteSpace(contact) ||
                string.IsNullOrWhiteSpace(gender) ||
                string.IsNullOrWhiteSpace(address) ||
                string.IsNullOrWhiteSpace(tipoIdent) ||
                string.IsNullOrWhiteSpace(numIdent))
            {
                throw new ArgumentException("Complete todos los campos antes de editar un cliente.");
            }

            try
            {
                conexion.Abrir();

                string query = @"UPDATE customer SET 
                                    full_name=@full_name, 
                                    email=@email, 
                                    contact=@contact, 
                                    gender=@gender, 
                                    address=@address, 
                                    tipo_identificacion=@tipoIdent, 
                                    numero_identificacion=@numIdent 
                                 WHERE id=@id";

                using (SqlCommand cmd = new SqlCommand(query, conexion.ObtenerConexion()))
                {
                    cmd.Parameters.AddWithValue("@full_name", fullName);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@contact", contact);
                    cmd.Parameters.AddWithValue("@gender", gender);
                    cmd.Parameters.AddWithValue("@address", address);
                    cmd.Parameters.AddWithValue("@tipoIdent", tipoIdent);
                    cmd.Parameters.AddWithValue("@numIdent", numIdent);
                    cmd.Parameters.AddWithValue("@id", id);

                    int rows = cmd.ExecuteNonQuery();
                    if (rows == 0)
                        throw new Exception("No se encontró el cliente a actualizar.");
                }
            }
            finally
            {
                conexion.Cerrar();
            }
        }
        public void DeleteCustomer(int id)
        {
            if (id <= 0)
                throw new ArgumentException("Debe seleccionar un cliente válido para eliminar.");

            try
            {
                conexion.Abrir();

                string query = "DELETE FROM customer WHERE id=@id";
                using (SqlCommand cmd = new SqlCommand(query, conexion.ObtenerConexion()))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    int rows = cmd.ExecuteNonQuery();

                    if (rows == 0)
                        throw new Exception("No se encontró el cliente a eliminar.");
                }
            }
            finally
            {
                conexion.Cerrar();
            }
        }
    }
}
