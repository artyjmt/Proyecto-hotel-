﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GestionHotel
{
    public partial class InfoCliente : Form
    {
        csConexion conexion = new csConexion();
        public InfoCliente()
        {

            InitializeComponent();
            displayData();
            RefreshData();
            displayBookID();
            client_contact.MaxLength = 10;
            client_contact.KeyPress += client_contact_KeyPress;
            client_contact.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumero_KeyPress);
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void displayBookID()
        {
            try
            {
                conexion.Abrir();
                string SelectBID = "SELECT COUNT(id) FROM customer";
                using (SqlCommand cmd = new SqlCommand(SelectBID, conexion.ObtenerConexion()))
                {
                    int count = Convert.ToInt32(cmd.ExecuteScalar());
                    int nextId = count == 0 ? 1 : count + 1;
                    client_bookID.Text = $"BID-{nextId}";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener ID de reserva: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }

        // Verifica si el nombre ya existe en la base de datos
        private bool IsNameDuplicate(string fullName)
        {
            try
            {
                conexion.Abrir();
                string query = "SELECT COUNT(*) FROM customer WHERE full_name = @fullname";
                using (SqlCommand cmd = new SqlCommand(query, conexion.ObtenerConexion()))
                {
                    cmd.Parameters.AddWithValue("@fullname", fullName);
                    int count = (int)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al verificar nombre duplicado: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            finally
            {
                conexion.Cerrar();
            }
        }

        private void client_bookBtn_Click(object sender, EventArgs e)
        {

        }

        // Solo permite números en el campo de contacto
        private void client_contact_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permite solo dígitos
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtNumero_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permite solo dígitos 
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void client_contact_TextChanged(object sender, EventArgs e)
        {

        }

        private void client_fullName_TextChanged(object sender, EventArgs e)
        {

        }

        private void client_fullName_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void client_fullName_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true; // Bloquea el carácter
            }
        }

        private void client_email_Leave(object sender, EventArgs e)
        {
            string email = client_email.Text.Trim();
            if (string.IsNullOrEmpty(email))
                return;
            if (!client_email.Text.Contains("@") || !client_email.Text.Contains("."))
            {
                MessageBox.Show("Correo inválido");
            }
        }

        private void client_clearBtn_Click(object sender, EventArgs e)
        {

        }

        public void displayData()
        {
            infoData iData = new infoData();
            List<infoData> listD = iData.ListCustomerData();
            dataGridView1.DataSource = listD;
        }

        public void RefreshData()
        {
            if (dataGridView1 == null)
            {
                MessageBox.Show("El control DataGridView no está inicializado.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                conexion.Abrir();

                string query = @"
    SELECT 
        book_id AS [ID Reserva],
        full_name AS [Nombre Completo],
        email AS [Correos Electrónico],
        contact AS [Número de Contacto],
        gender AS [Género],
        address AS [Dirección]
    FROM customer";

                    SqlDataAdapter da = new SqlDataAdapter(query, conexion.ObtenerConexion());
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("No se encontraron registros en la tabla 'customer'.",
                            "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    dataGridView1.AutoGenerateColumns = true;
                    dataGridView1.DataSource = dt;
                }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los datos: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (client_fullName.Text == "" || client_email.Text == "" || client_contact.Text == "" || client_address.Text == "")
            {
                MessageBox.Show("Por favor rellena todos los espacios en blanco", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (IsNameDuplicate(client_fullName.Text))
            {
                MessageBox.Show("El nombre ya está registrado. Por favor ingresa un nombre diferente.", "Nombre duplicado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try { 
                conexion.Abrir();
                string insertData = "INSERT INTO customer (full_name, email, contact, gender, address, price, status_payment, status, date_from, date_to, date_register) " +
                    "VALUES(@fullname, @email, @contact, @gender, @address, @price, @statusP, @status, @dateForm, @dateTo, @dateBook); SELECT SCOPE_IDENTITY();";
                using (SqlCommand cmd = new SqlCommand(insertData, conexion.ObtenerConexion()))
                {
                    cmd.Parameters.AddWithValue("@fullname", client_fullName.Text);
                    cmd.Parameters.AddWithValue("@email", client_email.Text);
                    cmd.Parameters.AddWithValue("@contact", client_contact.Text);
                    cmd.Parameters.AddWithValue("@gender", client_gender.SelectedItem?.ToString() ?? "");
                    cmd.Parameters.AddWithValue("@address", client_address.Text);
                    cmd.Parameters.AddWithValue("@price", hotelData.price);
                    cmd.Parameters.AddWithValue("@statusP", "Paid");
                    cmd.Parameters.AddWithValue("@status", "Checked in");
                    cmd.Parameters.AddWithValue("@dateForm", hotelData.fromDate);
                    cmd.Parameters.AddWithValue("@dateTo", hotelData.toDate);
                    DateTime today = DateTime.Now;
                    cmd.Parameters.AddWithValue("@dateBook", today);

                    int newId = Convert.ToInt32(cmd.ExecuteScalar());

                    string bookId = $"BID-{newId}";
                    string updateBookId = "UPDATE customer SET book_id = @bookId WHERE id = @id";
                    using (SqlCommand updateCmd = new SqlCommand(updateBookId, conexion.ObtenerConexion()))
                    {
                        updateCmd.Parameters.AddWithValue("@bookId", bookId);
                        updateCmd.Parameters.AddWithValue("@id", newId);
                        updateCmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Reservado con éxito", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Solo envía el nombre al panel administrativo


                    // Limpia los campos
                    client_fullName.Clear();
                    client_email.Clear();
                    client_contact.Clear();
                    client_address.Clear();
                    client_gender.SelectedIndex = -1;
                    displayBookID();
                    RefreshData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al conectar con la base de datos: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                    client_fullName.Text = row.Cells["Nombre Completo"].Value?.ToString();
                    client_email.Text = row.Cells["Correos Electrónico"].Value?.ToString();
                    client_contact.Text = row.Cells["Número de Contacto"].Value?.ToString();
                    client_address.Text = row.Cells["Dirección"].Value?.ToString();

                    // Para el género
                    string gender = row.Cells["Género"].Value?.ToString();
                    if (!string.IsNullOrEmpty(gender) && client_gender.Items.Contains(gender))
                    {
                        client_gender.SelectedItem = gender;
                    }
                    else
                    {
                        client_gender.SelectedIndex = -1;
                    }
                    displayData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al seleccionar fila: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Verificar que se haya seleccionado una fila en el DataGridView
            if (dataGridView1.CurrentRow == null)
                return;

            // Obtener el room_id de la fila seleccionada
            string roomId = dataGridView1.CurrentRow.Cells["Habitación"].Value?.ToString();
            if (string.IsNullOrEmpty(roomId))
                return;

            // Actualizar el estado de la habitación a 'Ocupado'
            try { 
                conexion.Abrir();
                string updateRoom = "UPDATE room SET status = 'Ocupado' WHERE room_id = @roomId";
                using (SqlCommand cmd = new SqlCommand(updateRoom, conexion.ObtenerConexion()))
                {
                    cmd.Parameters.AddWithValue("@roomId", roomId);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar el estado de la habitación: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }
    }
}
