﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionHotel
{
    internal class hotelData
    {
        public static string roomID = "";
        public static DateTime fromDate;
        public static DateTime toDate;
        public static string price;
    }
}
