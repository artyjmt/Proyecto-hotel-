﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace GestionHotel
{
    internal class infoData
    {
        private csConexion conexion = new csConexion();


        public int ID { get; set; }          // id (PK)
        public string FullName { get; set; } // full_name
        public string Email { get; set; }    // email
        public string Contact { get; set; }  // contact
        public string Gender { get; set; }   // gender
        public string Address { get; set; }  // address

        // 📌 Devuelve lista de usuarios (modo objeto)
        public List<infoData> ListCustomerData()
        {
            List<infoData> listData = new List<infoData>();

            try
            {
                conexion.Abrir();
                string selectData = "SELECT id, full_name, email, contact, gender, address FROM customer";

                    using (SqlCommand cmd = new SqlCommand(selectData, conexion.ObtenerConexion()))
                    {
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            infoData cData = new infoData
                            {
                                ID = (int)reader["id"],
                                FullName = reader["full_name"].ToString(),
                                Email = reader["email"].ToString(),
                                Contact = reader["contact"].ToString(),
                                Gender = reader["gender"].ToString(),
                                Address = reader["address"].ToString()
                            };

                            listData.Add(cData);
                        }
                    }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al conectar con la base de datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }

            return listData;
        }
    }
}
