﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionHotel
{
    public partial class ClientesAdmin : UserControl
    {
        csConexion conexion = new csConexion();
        public ClientesAdmin()
        {
            InitializeComponent();
            MostrarClientes();
        }

        public void RefreshData()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)RefreshData);
                return;
            }
            MostrarClientes();
        }

        private void MostrarClientes()
        {
            try { 
                conexion.Abrir();
                string query = "SELECT id, full_name, email, contact, gender, address, tipo_identificacion, numero_identificacion FROM customer";
                SqlDataAdapter da = new SqlDataAdapter(query, conexion.ObtenerConexion());
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt; // Asegúrate que el nombre del DataGridView es correcto
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ClientesAdmin_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
