﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GestionHotel
{
    internal class csAñadirUsuario
    {
        csConexion conexion = new csConexion();
        public void Añadir(string username, string password, string role, string status, string tipoIdentificacion, string numeroIdentificacion)
        {
            try
            {
                if (password.Length < 6)
                {
                    MessageBox.Show("La contraseña debe tener al menos 6 caracteres.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; // Salir del método sin ejecutar nada
                }

                conexion.Abrir();
                // Validar username duplicado
                string Query1 = "SELECT username FROM users WHERE username = @usern";
                using (SqlCommand checkCmd = new SqlCommand(Query1, conexion.ObtenerConexion()))
                {
                    checkCmd.Parameters.AddWithValue("@usern", username);
                    SqlDataAdapter sda = new SqlDataAdapter(checkCmd);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    if (dt.Rows.Count > 0)
                        throw new Exception($"El usuario '{username}' ya existe.");
                }

                // Validar identificación duplicada
                if (ExisteIdentificacion(tipoIdentificacion, numeroIdentificacion))
                    throw new Exception($"Ya existe un usuario con {tipoIdentificacion} {numeroIdentificacion}");

                conexion.Abrir();
                // Insertar
                string Query2 = @"INSERT INTO users 
                            (username, password, role, status, date_register, tipo_identificacion, numero_identificacion)
                            VALUES (@usern, @pass, @role, @status, @date, @tipoIdent, @numIdent)";
                using (SqlCommand cmd = new SqlCommand(Query2, conexion.ObtenerConexion()))
                {
                    cmd.Parameters.AddWithValue("@usern", username);
                    cmd.Parameters.AddWithValue("@pass", password);
                    cmd.Parameters.AddWithValue("@role", role);
                    cmd.Parameters.AddWithValue("@status", status);
                    cmd.Parameters.AddWithValue("@date", DateTime.Now);
                    cmd.Parameters.AddWithValue("@tipoIdent", tipoIdentificacion);
                    cmd.Parameters.AddWithValue("@numIdent", numeroIdentificacion);
                    cmd.ExecuteNonQuery();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al añadir usuario: " + ex.Message,
                      "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }

        public bool ExisteIdentificacion(string tipoIdentificacion, string numeroIdentificacion)
        {
            try
            {
                conexion.Abrir();

                string query = @"SELECT COUNT(*) 
                             FROM users 
                             WHERE tipo_identificacion = @tipoIdent 
                               AND numero_identificacion = @numIdent";

                using (SqlCommand cmd = new SqlCommand(query, conexion.ObtenerConexion()))
                {
                    cmd.Parameters.AddWithValue("@tipoIdent", tipoIdentificacion);
                    cmd.Parameters.AddWithValue("@numIdent", numeroIdentificacion);

                    int count = Convert.ToInt32(cmd.ExecuteScalar());
                    return count > 0;
                }

            }
            finally
            {
                conexion.Cerrar();
            }
        }


        public void Editar(int id,string username, string password, string role, string status, string tipoIdentificacion, string numeroIdentificacion)
        {
            try
            {
                conexion.Abrir();

                if (password.Length < 6)
                    throw new Exception("La contraseña debe tener al menos 6 caracteres");

                string Query3 = @"UPDATE users SET 
                                username=@usern,
                                password=@pass, 
                                role=@role, 
                                status=@status, 
                                tipo_identificacion=@tipoIdent, 
                                numero_identificacion=@numIdent 
                                WHERE id=@id";

                using (SqlCommand cmd = new SqlCommand(Query3, conexion.ObtenerConexion()))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@usern", username);
                    cmd.Parameters.AddWithValue("@pass", password);
                    cmd.Parameters.AddWithValue("@role", role);
                    cmd.Parameters.AddWithValue("@status", status);
                    cmd.Parameters.AddWithValue("@tipoIdent", tipoIdentificacion);
                    cmd.Parameters.AddWithValue("@numIdent", numeroIdentificacion);

                    int filas = cmd.ExecuteNonQuery();

                    if (filas == 0)
                        throw new Exception("No se encontró el usuario para actualizar.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al editar usuario: " + ex.Message,
                   "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }

        public void Eliminar(string username)
        {
            try
            {
                conexion.Abrir();
                string Query4 = "DELETE FROM users WHERE username=@username";
                using (SqlCommand cmd = new SqlCommand(Query4, conexion.ObtenerConexion()))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.ExecuteNonQuery();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar usuario: " + ex.Message,
                         "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }
        public DataTable ObtenerUsuarios()
        {
            DataTable dt = new DataTable();
            try
            {
                conexion.Abrir();

                string query = "SELECT username AS nombre_usuario, numero_identificacion FROM users";
                using (SqlCommand cmd = new SqlCommand(query, conexion.ObtenerConexion()))
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            finally
            {
                conexion.Cerrar();
            }

            return dt;
        }

    }
}
