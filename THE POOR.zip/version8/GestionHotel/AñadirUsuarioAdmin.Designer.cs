﻿namespace GestionHotel
{
    partial class AñadirUsuarioAdmin
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.addUser_tipoIdentificacion = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.addUser_numIdentificacion = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.addUser_clearBtn = new System.Windows.Forms.Button();
            this.addUser_deleteBtn = new System.Windows.Forms.Button();
            this.addUser_uptadeBtn = new System.Windows.Forms.Button();
            this.addUser_addBtn = new System.Windows.Forms.Button();
            this.addUser_status = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.addUser_role = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.addUser_password = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.addUser_username = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.addUser_tipoIdentificacion);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.addUser_numIdentificacion);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.addUser_clearBtn);
            this.panel1.Controls.Add(this.addUser_deleteBtn);
            this.panel1.Controls.Add(this.addUser_uptadeBtn);
            this.panel1.Controls.Add(this.addUser_addBtn);
            this.panel1.Controls.Add(this.addUser_status);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.addUser_role);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.addUser_password);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.addUser_username);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(13, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(284, 648);
            this.panel1.TabIndex = 0;
            // 
            // addUser_tipoIdentificacion
            // 
            this.addUser_tipoIdentificacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUser_tipoIdentificacion.FormattingEnabled = true;
            this.addUser_tipoIdentificacion.Items.AddRange(new object[] {
            "RUC",
            "Cédula",
            "Pasaporte"});
            this.addUser_tipoIdentificacion.Location = new System.Drawing.Point(18, 176);
            this.addUser_tipoIdentificacion.Name = "addUser_tipoIdentificacion";
            this.addUser_tipoIdentificacion.Size = new System.Drawing.Size(250, 28);
            this.addUser_tipoIdentificacion.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(17, 153);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(135, 20);
            this.label7.TabIndex = 14;
            this.label7.Text = "Tipo identificacion";
            // 
            // addUser_numIdentificacion
            // 
            this.addUser_numIdentificacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUser_numIdentificacion.Location = new System.Drawing.Point(19, 235);
            this.addUser_numIdentificacion.Name = "addUser_numIdentificacion";
            this.addUser_numIdentificacion.Size = new System.Drawing.Size(250, 26);
            this.addUser_numIdentificacion.TabIndex = 13;
            this.addUser_numIdentificacion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.addUser_numIdentificacion_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(17, 212);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 20);
            this.label6.TabIndex = 12;
            this.label6.Text = "Identificacion";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // addUser_clearBtn
            // 
            this.addUser_clearBtn.BackColor = System.Drawing.Color.MidnightBlue;
            this.addUser_clearBtn.FlatAppearance.BorderSize = 0;
            this.addUser_clearBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.RoyalBlue;
            this.addUser_clearBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue;
            this.addUser_clearBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addUser_clearBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUser_clearBtn.ForeColor = System.Drawing.Color.White;
            this.addUser_clearBtn.Location = new System.Drawing.Point(17, 584);
            this.addUser_clearBtn.Name = "addUser_clearBtn";
            this.addUser_clearBtn.Size = new System.Drawing.Size(250, 41);
            this.addUser_clearBtn.TabIndex = 11;
            this.addUser_clearBtn.Text = "Limpiar";
            this.addUser_clearBtn.UseVisualStyleBackColor = false;
            this.addUser_clearBtn.Click += new System.EventHandler(this.addUser_clearBtn_Click);
            // 
            // addUser_deleteBtn
            // 
            this.addUser_deleteBtn.BackColor = System.Drawing.Color.MidnightBlue;
            this.addUser_deleteBtn.FlatAppearance.BorderSize = 0;
            this.addUser_deleteBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.RoyalBlue;
            this.addUser_deleteBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue;
            this.addUser_deleteBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addUser_deleteBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUser_deleteBtn.ForeColor = System.Drawing.Color.White;
            this.addUser_deleteBtn.Location = new System.Drawing.Point(17, 526);
            this.addUser_deleteBtn.Name = "addUser_deleteBtn";
            this.addUser_deleteBtn.Size = new System.Drawing.Size(250, 41);
            this.addUser_deleteBtn.TabIndex = 10;
            this.addUser_deleteBtn.Text = "Eliminar";
            this.addUser_deleteBtn.UseVisualStyleBackColor = false;
            this.addUser_deleteBtn.Click += new System.EventHandler(this.addUser_deleteBtn_Click);
            // 
            // addUser_uptadeBtn
            // 
            this.addUser_uptadeBtn.BackColor = System.Drawing.Color.MidnightBlue;
            this.addUser_uptadeBtn.FlatAppearance.BorderSize = 0;
            this.addUser_uptadeBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.RoyalBlue;
            this.addUser_uptadeBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue;
            this.addUser_uptadeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addUser_uptadeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUser_uptadeBtn.ForeColor = System.Drawing.Color.White;
            this.addUser_uptadeBtn.Location = new System.Drawing.Point(17, 466);
            this.addUser_uptadeBtn.Name = "addUser_uptadeBtn";
            this.addUser_uptadeBtn.Size = new System.Drawing.Size(250, 41);
            this.addUser_uptadeBtn.TabIndex = 9;
            this.addUser_uptadeBtn.Text = "Editar";
            this.addUser_uptadeBtn.UseVisualStyleBackColor = false;
            this.addUser_uptadeBtn.Click += new System.EventHandler(this.addUser_uptadeBtn_Click);
            // 
            // addUser_addBtn
            // 
            this.addUser_addBtn.BackColor = System.Drawing.Color.MidnightBlue;
            this.addUser_addBtn.FlatAppearance.BorderSize = 0;
            this.addUser_addBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.RoyalBlue;
            this.addUser_addBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue;
            this.addUser_addBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addUser_addBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUser_addBtn.ForeColor = System.Drawing.Color.White;
            this.addUser_addBtn.Location = new System.Drawing.Point(17, 408);
            this.addUser_addBtn.Name = "addUser_addBtn";
            this.addUser_addBtn.Size = new System.Drawing.Size(250, 41);
            this.addUser_addBtn.TabIndex = 8;
            this.addUser_addBtn.Text = "Añadir";
            this.addUser_addBtn.UseVisualStyleBackColor = false;
            this.addUser_addBtn.Click += new System.EventHandler(this.addUser_addBtn_Click);
            // 
            // addUser_status
            // 
            this.addUser_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUser_status.FormattingEnabled = true;
            this.addUser_status.Items.AddRange(new object[] {
            "Activo",
            "Inactivo"});
            this.addUser_status.Location = new System.Drawing.Point(18, 356);
            this.addUser_status.Name = "addUser_status";
            this.addUser_status.Size = new System.Drawing.Size(250, 28);
            this.addUser_status.TabIndex = 7;
            this.addUser_status.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 335);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Estado";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // addUser_role
            // 
            this.addUser_role.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUser_role.FormattingEnabled = true;
            this.addUser_role.Items.AddRange(new object[] {
            "Administrador",
            "Recepcionista"});
            this.addUser_role.Location = new System.Drawing.Point(18, 291);
            this.addUser_role.Name = "addUser_role";
            this.addUser_role.Size = new System.Drawing.Size(250, 28);
            this.addUser_role.TabIndex = 5;
            this.addUser_role.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 270);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Cargo";
            // 
            // addUser_password
            // 
            this.addUser_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUser_password.Location = new System.Drawing.Point(17, 125);
            this.addUser_password.Name = "addUser_password";
            this.addUser_password.Size = new System.Drawing.Size(250, 26);
            this.addUser_password.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Contraseña";
            // 
            // addUser_username
            // 
            this.addUser_username.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUser_username.Location = new System.Drawing.Point(17, 59);
            this.addUser_username.Name = "addUser_username";
            this.addUser_username.Size = new System.Drawing.Size(250, 26);
            this.addUser_username.TabIndex = 1;
            this.addUser_username.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(146, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre de Usuario";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.dataGridView1);
            this.panel2.Location = new System.Drawing.Point(317, 13);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(637, 648);
            this.panel2.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(11, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(165, 20);
            this.label5.TabIndex = 12;
            this.label5.Text = "Datos de los Usuarios";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.dataGridView1.Location = new System.Drawing.Point(14, 59);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView1.Size = new System.Drawing.Size(612, 575);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // AñadirUsuarioAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "AñadirUsuarioAdmin";
            this.Size = new System.Drawing.Size(967, 676);
            this.Load += new System.EventHandler(this.AñadirUsuarioAdmin_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox addUser_username;
        private System.Windows.Forms.ComboBox addUser_role;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox addUser_password;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox addUser_status;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button addUser_addBtn;
        private System.Windows.Forms.Button addUser_uptadeBtn;
        private System.Windows.Forms.Button addUser_clearBtn;
        private System.Windows.Forms.Button addUser_deleteBtn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox addUser_tipoIdentificacion;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox addUser_numIdentificacion;
        private System.Windows.Forms.Label label6;
    }
}
