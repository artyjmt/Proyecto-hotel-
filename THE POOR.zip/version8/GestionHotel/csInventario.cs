﻿using System;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace GestionHotel
{
    internal class csInventario
    {
        private csConexion conexion = new csConexion();
        public void AñadirInventario(string NombreP, string candidadP)
        {
            try
            {
                conexion.Abrir();
                // Verificar si el producto ya existe en el inventario
                string checkProducto = "SELECT id_producto FROM Productos WHERE nombre = @nombre";
                using (SqlCommand checkCmd = new SqlCommand(checkProducto, conexion.ObtenerConexion()))
                {
                    
                    checkCmd.Parameters.AddWithValue("@nombre", NombreP.Trim());
                    object result = checkCmd.ExecuteScalar();

                    int idProducto;

                    if (result != null) // Ya existe en la tabla Productos
                    {
                        idProducto = Convert.ToInt32(result);
                    }
                    else
                    {
                        // Insertar en tabla Productos si no existe
                        string insertProducto = "INSERT INTO Productos (nombre) OUTPUT INSERTED.id_producto VALUES (@nombre)";
                        using (SqlCommand insertCmd = new SqlCommand(insertProducto, conexion.ObtenerConexion()))
                        {
                            insertCmd.Parameters.AddWithValue("@nombre", NombreP.Trim());
                            idProducto = (int)insertCmd.ExecuteScalar();
                        }
                    }

                    // Insertar en Inventario
                    string insertInventario = "INSERT INTO Inventario (id_producto, cantidad, fecha_registro) " +
                                              "VALUES (@id_producto, @cantidad, @fecha_registro)";
                    using (SqlCommand cmd = new SqlCommand(insertInventario, conexion.ObtenerConexion()))
                    {
                        cmd.Parameters.AddWithValue("@id_producto", idProducto);
                        cmd.Parameters.AddWithValue("@cantidad", Convert.ToInt32(candidadP.Trim()));
                        cmd.Parameters.AddWithValue("@fecha_registro", DateTime.Now);

                        cmd.ExecuteNonQuery(); // Refresca tu DataGridView
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al añadir el producto al Inventario: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();

            }
        }
        public void EditarInventario(int Idinventario, string NombrePr, string cantidad)
        {
            try
            {
                conexion.Abrir();
                // Primero actualizamos el nombre del producto en la tabla Productos
                string updateProducto = "UPDATE Productos SET nombre = @nombre WHERE id_producto = " +
                                        "(SELECT id_producto FROM Inventario WHERE id_inventario = @idInventario)";
                using (SqlCommand cmd = new SqlCommand(updateProducto, conexion.ObtenerConexion()))
                {
                    cmd.Parameters.AddWithValue("@nombre", NombrePr.Trim());
                    cmd.Parameters.AddWithValue("@idInventario", Idinventario);
                    cmd.ExecuteNonQuery();
                }

                // Luego actualizamos la cantidad en Inventario
                string updateInventario = "UPDATE Inventario SET cantidad = @cantidad, fecha_registro = @fecha WHERE id_inventario = @id";
                using (SqlCommand cmd = new SqlCommand(updateInventario, conexion.ObtenerConexion()))
                {
                    cmd.Parameters.AddWithValue("@cantidad", Convert.ToInt32(cantidad.Trim()));
                    cmd.Parameters.AddWithValue("@fecha", DateTime.Now);
                    cmd.Parameters.AddWithValue("@id", Idinventario);
                    cmd.ExecuteNonQuery();
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar el registro: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }

       
        public void EliminarRegistroCompleto(int Idinventario, int Idventa)
        {
            try
            {
                conexion.Abrir();

                int idproducto = -1;

                // 1. Buscar id_producto según Inventario
                if (Idinventario > 0)
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT id_producto FROM Inventario WHERE id_inventario = @id", conexion.ObtenerConexion()))
                    {
                        cmd.Parameters.AddWithValue("@id", Idinventario);
                        object result = cmd.ExecuteScalar();
                        if (result != null)
                            idproducto = Convert.ToInt32(result);
                    }

                    // Eliminar Inventario
                    using (SqlCommand cmd = new SqlCommand("DELETE FROM Inventario WHERE id_inventario = @id", conexion.ObtenerConexion()))
                    {
                        cmd.Parameters.AddWithValue("@id", Idinventario);
                        cmd.ExecuteNonQuery();
                    }
                }

                //POR VER
                // 2. Buscar id_producto según ProductosVenta
                if (Idventa > 0)
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT id_producto FROM ProductosVenta WHERE id_venta = @id", conexion.ObtenerConexion()))
                    {
                        cmd.Parameters.AddWithValue("@id", Idventa);
                        object result = cmd.ExecuteScalar();
                        if (result != null)
                            idproducto = Convert.ToInt32(result);
                    }

                    // Eliminar ProductosVenta
                    using (SqlCommand cmd = new SqlCommand("DELETE FROM ProductosVenta WHERE id_venta = @id", conexion.ObtenerConexion()))
                    {
                        cmd.Parameters.AddWithValue("@id", Idventa);
                        cmd.ExecuteNonQuery();
                    }
                }

                // 3. Eliminar producto de Productos solo si no existe en Inventario ni ProductosVenta
                if (idproducto > 0)
                {
                    int count = 0;
                    
                    using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Inventario WHERE id_producto = @id", conexion.ObtenerConexion()))
                    {
                        cmd.Parameters.AddWithValue("@id", idproducto);
                        count += (int)cmd.ExecuteScalar();
                    }
                    //POR VER
                    using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM ProductosVenta WHERE id_producto = @id", conexion.ObtenerConexion()))
                    {
                        cmd.Parameters.AddWithValue("@id", idproducto);
                        count += (int)cmd.ExecuteScalar();
                    }
                    // eliminar d eproductos
                    if (count == 0)
                    {
                        using (SqlCommand cmd = new SqlCommand("DELETE FROM Productos WHERE id_producto = @id", conexion.ObtenerConexion()))
                        {
                            cmd.Parameters.AddWithValue("@id", idproducto);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar el registro: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }

        public void AañadirProductosVenta(string Producto, string Cantidad, string precio, string ImagenRuta)
        {

            try
            {
                conexion.Abrir();
                // Verificar si el producto ya existe en la tabla Productos
                string checkProducto = "SELECT id_producto FROM Productos WHERE nombre = @nombre";
                using (SqlCommand checkCmd = new SqlCommand(checkProducto, conexion.ObtenerConexion()))
                {
                    
                    checkCmd.Parameters.AddWithValue("@nombre", Producto.Trim());
                    object result = checkCmd.ExecuteScalar();

                    int idProducto;

                    if (result != null) // Ya existe en la tabla Productos
                    {
                        idProducto = Convert.ToInt32(result);
                    }
                    else
                    {
                        // Insertar producto nuevo en la tabla Productos
                        string insertProducto = "INSERT INTO Productos (nombre) OUTPUT INSERTED.id_producto VALUES (@nombre)";
                        using (SqlCommand insertCmd = new SqlCommand(insertProducto, conexion.ObtenerConexion()))
                        {
                            insertCmd.Parameters.AddWithValue("@nombre", Producto.Trim());
                            idProducto = (int)insertCmd.ExecuteScalar();
                        }
                    }

                    // Guardar imagen en carpeta
                    string carpeta = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "GestionHotel", "room_directory");
                    if (!Directory.Exists(carpeta))
                        Directory.CreateDirectory(carpeta);

                    string imagePath = Path.Combine(carpeta, Producto.Trim() + ".jpg");
                    File.Copy(ImagenRuta, imagePath, true);

                    // Insertar en ProductosVenta
                    string insertVenta = "INSERT INTO ProductosVenta (id_producto, cantidad, precio, fecha_registro, image1_path) " +
                                         "VALUES (@id_producto, @cantidad, @precio, @fecha_registro, @path)";
                    using (SqlCommand cmd = new SqlCommand(insertVenta, conexion.ObtenerConexion()))
                    {
                        cmd.Parameters.AddWithValue("@id_producto", idProducto);
                        cmd.Parameters.AddWithValue("@cantidad", Convert.ToInt32(Cantidad.Trim()));
                        cmd.Parameters.AddWithValue("@precio", Convert.ToDecimal(precio.Trim()));
                        cmd.Parameters.AddWithValue("@fecha_registro", DateTime.Now);
                        cmd.Parameters.AddWithValue("@path", imagePath);

                        cmd.ExecuteNonQuery();
                        // Refresca tu DataGridView
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al añadir el producto a Ventas: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            finally
            {
                conexion.Cerrar();

            }
        }
        public void EditarProductosVenta2(int IdInventario, int IdVenta, string Producto, string cantidadStr, string precioStr)
        {
            try
            {
                conexion.Abrir();
                // POR VER
                if (IdInventario != -1)
                {
                    // Obtener id_producto asociado al inventario
                    int idProducto = -1;
                    string getProductoQuery = "SELECT id_producto FROM Inventario WHERE id_inventario = @id";
                    using (SqlCommand cmd = new SqlCommand(getProductoQuery, conexion.ObtenerConexion()))
                    {
                        cmd.Parameters.AddWithValue("@id", IdInventario);
                        object result = cmd.ExecuteScalar();
                        if (result != null)
                            idProducto = Convert.ToInt32(result);
                    }

                    // 2. Actualizar Inventario
                    string query = "UPDATE Inventario SET cantidad = @cantidad, fecha_registro = @fecha WHERE id_inventario = @id";
                    using (SqlCommand cmd = new SqlCommand(query, conexion.ObtenerConexion()))
                    {
                        cmd.Parameters.AddWithValue("@cantidad", Convert.ToInt32(cantidadStr.Trim()));
                        cmd.Parameters.AddWithValue("@fecha", DateTime.Now);
                        cmd.Parameters.AddWithValue("@id", IdInventario);
                        cmd.ExecuteNonQuery();
                    }


                    if (idProducto != -1 && !string.IsNullOrWhiteSpace(Producto))
                    {
                        string updateProducto = "UPDATE Productos SET nombre = @nombre WHERE id_producto = @id_producto";
                        using (SqlCommand cmd = new SqlCommand(updateProducto, conexion.ObtenerConexion()))
                        {
                            cmd.Parameters.AddWithValue("@nombre", Producto.Trim());
                            cmd.Parameters.AddWithValue("@id_producto", idProducto);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }

                // Verificar y actualizar ProductosVenta si IdVenta es válido
                if (IdVenta != -1)
                {
                    // Obtener id_producto asociado a la venta
                    int idProducto = -1;
                    string getProductoQuery = "SELECT id_producto FROM ProductosVenta WHERE id_venta = @id";
                    using (SqlCommand cmd = new SqlCommand(getProductoQuery, conexion.ObtenerConexion()))
                    {
                        cmd.Parameters.AddWithValue("@id", IdVenta);
                        object result = cmd.ExecuteScalar();
                        if (result != null)
                            idProducto = Convert.ToInt32(result);
                    }

                    //  Actualizar ProductosVenta
                    string query = "UPDATE ProductosVenta SET cantidad = @cantidad, precio = @precio, fecha_registro = @fecha WHERE id_venta = @id";
                    using (SqlCommand cmd = new SqlCommand(query, conexion.ObtenerConexion()))
                    {
                        cmd.Parameters.AddWithValue("@cantidad", Convert.ToInt32(cantidadStr.Trim()));
                        cmd.Parameters.AddWithValue("@precio", Convert.ToDecimal(precioStr.Trim()));
                        cmd.Parameters.AddWithValue("@fecha", DateTime.Now);
                        cmd.Parameters.AddWithValue("@id", IdVenta);
                        cmd.ExecuteNonQuery();
                    }

                    // Actualizar nombre del producto en la tabla Productos si es necesario
                    if (idProducto != -1 && !string.IsNullOrWhiteSpace(Producto))
                    {
                        string updateProducto = "UPDATE Productos SET nombre = @nombre WHERE id_producto = @id_producto";
                        using (SqlCommand cmd = new SqlCommand(updateProducto, conexion.ObtenerConexion()))
                        {
                            cmd.Parameters.AddWithValue("@nombre", Producto.Trim());
                            cmd.Parameters.AddWithValue("@id_producto", idProducto);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar el registro: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }
        public void EliminarProductosVenta2(int idinve, int idvent)
        {
            try
            {
                conexion.Abrir();

                int idproducto = -1;
                // POR VER  
                // 1. buscar id_producto según inventario o venta
                if (idinve > 0)
                {
                    string getidprod = "SELECT id_producto FROM Inventario WHERE id_inventario = @id";
                    using (SqlCommand cmd = new SqlCommand(getidprod, conexion.ObtenerConexion()))
                    {
                        cmd.Parameters.AddWithValue("@id", idinve);
                        object result = cmd.ExecuteScalar();
                        if (result != null)
                            idproducto = Convert.ToInt32(result);
                    }

                    // eliminar inventario
                    string queryinventario = "DELETE FROM Inventario WHERE id_inventario = @id";
                    using (SqlCommand cmd = new SqlCommand(queryinventario, conexion.ObtenerConexion()))
                    {
                        cmd.Parameters.AddWithValue("@id", idinve);
                        cmd.ExecuteNonQuery();
                    }
                }
                // buscar id_producto según venta
                if (idvent > 0)
                {
                    string getidprod = "SELECT id_producto FROM ProductosVenta WHERE id_venta = @id";
                    using (SqlCommand cmd = new SqlCommand(getidprod, conexion.ObtenerConexion()))
                    {
                        cmd.Parameters.AddWithValue("@id", idvent);
                        object result = cmd.ExecuteScalar();
                        if (result != null)
                            idproducto = Convert.ToInt32(result);
                    }

                    // eliminar venta
                    string queryventa = "DELETE FROM ProductosVenta WHERE id_venta = @id";
                    using (SqlCommand cmd = new SqlCommand(queryventa, conexion.ObtenerConexion()))
                    {
                        cmd.Parameters.AddWithValue("@id", idvent);
                        cmd.ExecuteNonQuery();
                    }
                }

                // 2. eliminar también de la tabla productos si obtuvimos el id_producto
                if (idproducto > 0)
                {
                    string queryproducto = "DELETE FROM Productos WHERE id_producto = @id";
                    using (SqlCommand cmd = new SqlCommand(queryproducto, conexion.ObtenerConexion()))
                    {
                        cmd.Parameters.AddWithValue("@id", idproducto);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar el registro: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }
    }
}
