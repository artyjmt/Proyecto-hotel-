﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GestionHotel
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void login_btn_Click(object sender, EventArgs e)
        {
            csConexion conexion = new csConexion();

            if (login_username.Text == "" || login_password.Text == "")
            {
                MessageBox.Show("Por favor rellena todos los espacios en blanco", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    conexion.Abrir();
                    string selecData = "SELECT role FROM users WHERE username = @usern AND password = @pass AND status = @status";
                    using (SqlCommand cmd = new SqlCommand(selecData, conexion.ObtenerConexion()))
                    {
                        cmd.Parameters.AddWithValue("@usern", login_username.Text.Trim());
                        cmd.Parameters.AddWithValue("@pass", login_password.Text.Trim());
                        cmd.Parameters.AddWithValue("@status", "Activo"); // O "Active" según tu base de datos

                        object result = cmd.ExecuteScalar();
                        if (result != null)
                        {
                            string userRole = result.ToString();
                            if (userRole == "Administrador")
                            {
                                MenuAdmin adminForm = new MenuAdmin();
                                adminForm.Show();
                                this.Hide();
                                MessageBox.Show("Bienvenido Administrador", "Mensaje Informativo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else if (userRole == "Recepcionista" || userRole == "Staff")
                            {
                                MenuPersonal personalForm = new MenuPersonal();
                                personalForm.Show();
                                this.Hide();
                                MessageBox.Show("Bienvenido Empleado", "Mensaje Informativo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                var panelAdmin = new PanelAdministración();
                                var reservarEmpleado = new ReservarHotelEmpleado();
                                reservarEmpleado.SetPanelAdministracion(panelAdmin);
                            }
                            else
                            {
                                MessageBox.Show("Rol de usuario desconocido", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Usuario o contraseña incorrectos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al conectar con la base de datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conexion.Cerrar();

                }
            }
        }

        private void login_showPass_CheckedChanged(object sender, EventArgs e)
        {
            login_password.PasswordChar = login_showPass.Checked ? '\0' : '*';
        }

        private void login_signupbtn_Click(object sender, EventArgs e)
        {
            Registrar regform = new Registrar();
            regform.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
