﻿namespace GestionHotel
{
    partial class ReservarHotelEmpleado
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.bookRoom_imageView = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.bookRoom_roomID = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.bookRoom_roomName = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.bookRoom_roomType = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.bookRoom_total = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.bookRoom_status = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.bookRoom_from = new System.Windows.Forms.DateTimePicker();
            this.bookRoom_to = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.bookRoom_getPrecio = new System.Windows.Forms.Label();
            this.bookpaga_Btn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.comboMetodoPago = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTarjeta = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.textbuscador = new System.Windows.Forms.TextBox();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bookRoom_imageView)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Location = new System.Drawing.Point(9, 445);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(615, 218);
            this.panel6.TabIndex = 5;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.LightGray;
            this.panel7.Controls.Add(this.bookRoom_imageView);
            this.panel7.Location = new System.Drawing.Point(20, 18);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(580, 187);
            this.panel7.TabIndex = 0;
            // 
            // bookRoom_imageView
            // 
            this.bookRoom_imageView.BackColor = System.Drawing.Color.LightGray;
            this.bookRoom_imageView.Location = new System.Drawing.Point(0, 0);
            this.bookRoom_imageView.Name = "bookRoom_imageView";
            this.bookRoom_imageView.Size = new System.Drawing.Size(580, 187);
            this.bookRoom_imageView.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bookRoom_imageView.TabIndex = 0;
            this.bookRoom_imageView.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Controls.Add(this.dataGridView1);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Location = new System.Drawing.Point(9, 14);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(615, 410);
            this.panel5.TabIndex = 4;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.Location = new System.Drawing.Point(20, 34);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView1.Size = new System.Drawing.Size(580, 368);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(279, 25);
            this.label4.TabIndex = 4;
            this.label4.Text = "Habitaciones Disponibles";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(54, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "Habitacion ID:";
            // 
            // bookRoom_roomID
            // 
            this.bookRoom_roomID.AutoSize = true;
            this.bookRoom_roomID.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookRoom_roomID.Location = new System.Drawing.Point(169, 30);
            this.bookRoom_roomID.Name = "bookRoom_roomID";
            this.bookRoom_roomID.Size = new System.Drawing.Size(56, 18);
            this.bookRoom_roomID.TabIndex = 6;
            this.bookRoom_roomID.Text = "--------";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(18, 90);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(154, 16);
            this.label7.TabIndex = 9;
            this.label7.Text = "Nombre Habitacion:";
            // 
            // bookRoom_roomName
            // 
            this.bookRoom_roomName.AutoSize = true;
            this.bookRoom_roomName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookRoom_roomName.Location = new System.Drawing.Point(170, 90);
            this.bookRoom_roomName.Name = "bookRoom_roomName";
            this.bookRoom_roomName.Size = new System.Drawing.Size(56, 18);
            this.bookRoom_roomName.TabIndex = 10;
            this.bookRoom_roomName.Text = "--------";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(42, 60);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(130, 16);
            this.label10.TabIndex = 11;
            this.label10.Text = "Tipo Habitacion:";
            // 
            // bookRoom_roomType
            // 
            this.bookRoom_roomType.AutoSize = true;
            this.bookRoom_roomType.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookRoom_roomType.Location = new System.Drawing.Point(169, 60);
            this.bookRoom_roomType.Name = "bookRoom_roomType";
            this.bookRoom_roomType.Size = new System.Drawing.Size(56, 18);
            this.bookRoom_roomType.TabIndex = 12;
            this.bookRoom_roomType.Text = "--------";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(53, 358);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(151, 20);
            this.label12.TabIndex = 13;
            this.label12.Text = "Precio Total ($):";
            // 
            // bookRoom_total
            // 
            this.bookRoom_total.AutoSize = true;
            this.bookRoom_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookRoom_total.Location = new System.Drawing.Point(210, 360);
            this.bookRoom_total.Name = "bookRoom_total";
            this.bookRoom_total.Size = new System.Drawing.Size(40, 18);
            this.bookRoom_total.TabIndex = 14;
            this.bookRoom_total.Text = "0.00";
            this.bookRoom_total.Click += new System.EventHandler(this.bookRoom_total_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(27, 124);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(145, 16);
            this.label14.TabIndex = 15;
            this.label14.Text = "Estado Habitacion:";
            // 
            // bookRoom_status
            // 
            this.bookRoom_status.AutoSize = true;
            this.bookRoom_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookRoom_status.Location = new System.Drawing.Point(170, 124);
            this.bookRoom_status.Name = "bookRoom_status";
            this.bookRoom_status.Size = new System.Drawing.Size(56, 18);
            this.bookRoom_status.TabIndex = 16;
            this.bookRoom_status.Text = "--------";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(27, 225);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(99, 16);
            this.label15.TabIndex = 19;
            this.label15.Text = "De la Fecha:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(8, 254);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(119, 16);
            this.label16.TabIndex = 20;
            this.label16.Text = "Hasta la Fecha:";
            // 
            // bookRoom_from
            // 
            this.bookRoom_from.Location = new System.Drawing.Point(125, 225);
            this.bookRoom_from.Name = "bookRoom_from";
            this.bookRoom_from.Size = new System.Drawing.Size(200, 20);
            this.bookRoom_from.TabIndex = 21;
            // 
            // bookRoom_to
            // 
            this.bookRoom_to.Location = new System.Drawing.Point(125, 254);
            this.bookRoom_to.Name = "bookRoom_to";
            this.bookRoom_to.Size = new System.Drawing.Size(200, 20);
            this.bookRoom_to.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(41, 181);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(167, 20);
            this.label2.TabIndex = 26;
            this.label2.Text = "Precio por dia ($):";
            // 
            // bookRoom_getPrecio
            // 
            this.bookRoom_getPrecio.AutoSize = true;
            this.bookRoom_getPrecio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookRoom_getPrecio.Location = new System.Drawing.Point(210, 181);
            this.bookRoom_getPrecio.Name = "bookRoom_getPrecio";
            this.bookRoom_getPrecio.Size = new System.Drawing.Size(40, 18);
            this.bookRoom_getPrecio.TabIndex = 27;
            this.bookRoom_getPrecio.Text = "0.00";
            // 
            // bookpaga_Btn
            // 
            this.bookpaga_Btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bookpaga_Btn.FlatAppearance.BorderSize = 0;
            this.bookpaga_Btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.RoyalBlue;
            this.bookpaga_Btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue;
            this.bookpaga_Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bookpaga_Btn.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookpaga_Btn.ForeColor = System.Drawing.Color.White;
            this.bookpaga_Btn.Location = new System.Drawing.Point(36, 569);
            this.bookpaga_Btn.Name = "bookpaga_Btn";
            this.bookpaga_Btn.Size = new System.Drawing.Size(267, 33);
            this.bookpaga_Btn.TabIndex = 28;
            this.bookpaga_Btn.Text = "Pagar";
            this.bookpaga_Btn.UseVisualStyleBackColor = false;
            this.bookpaga_Btn.Click += new System.EventHandler(this.bookpaga_Btn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 479);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 16);
            this.label1.TabIndex = 8;
            this.label1.Text = "Metodo de pago:";
            // 
            // comboMetodoPago
            // 
            this.comboMetodoPago.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboMetodoPago.FormattingEnabled = true;
            this.comboMetodoPago.Items.AddRange(new object[] {
            "Efectivo",
            "Tarjeta de credito/debito"});
            this.comboMetodoPago.Location = new System.Drawing.Point(153, 476);
            this.comboMetodoPago.Name = "comboMetodoPago";
            this.comboMetodoPago.Size = new System.Drawing.Size(162, 28);
            this.comboMetodoPago.TabIndex = 9;
            this.comboMetodoPago.SelectedIndexChanged += new System.EventHandler(this.comboMetodoPago_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(54, 516);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 16);
            this.label9.TabIndex = 57;
            this.label9.Text = "Nro Tarjeta:";
            // 
            // txtTarjeta
            // 
            this.txtTarjeta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTarjeta.Location = new System.Drawing.Point(152, 510);
            this.txtTarjeta.Name = "txtTarjeta";
            this.txtTarjeta.Size = new System.Drawing.Size(162, 26);
            this.txtTarjeta.TabIndex = 58;
            this.txtTarjeta.TextChanged += new System.EventHandler(this.txtTarjeta_TextChanged);
            this.txtTarjeta.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTarjeta_KeyPress);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Lavender;
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.textbuscador);
            this.panel4.Controls.Add(this.txtTarjeta);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.comboMetodoPago);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.bookpaga_Btn);
            this.panel4.Controls.Add(this.bookRoom_getPrecio);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.bookRoom_to);
            this.panel4.Controls.Add(this.bookRoom_from);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.bookRoom_status);
            this.panel4.Controls.Add(this.label14);
            this.panel4.Controls.Add(this.bookRoom_total);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.bookRoom_roomType);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.bookRoom_roomName);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.bookRoom_roomID);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Location = new System.Drawing.Point(630, 14);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(328, 649);
            this.panel4.TabIndex = 3;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(86, 449);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 16);
            this.label3.TabIndex = 60;
            this.label3.Text = "cliente:";
            // 
            // textbuscador
            // 
            this.textbuscador.Location = new System.Drawing.Point(152, 445);
            this.textbuscador.Name = "textbuscador";
            this.textbuscador.Size = new System.Drawing.Size(162, 20);
            this.textbuscador.TabIndex = 59;
            this.textbuscador.TextChanged += new System.EventHandler(this.textbuscador_TextChanged);
            // 
            // ReservarHotelEmpleado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Name = "ReservarHotelEmpleado";
            this.Size = new System.Drawing.Size(967, 676);
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bookRoom_imageView)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PictureBox bookRoom_imageView;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label bookRoom_roomID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label bookRoom_roomName;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label bookRoom_roomType;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label bookRoom_total;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label bookRoom_status;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DateTimePicker bookRoom_from;
        private System.Windows.Forms.DateTimePicker bookRoom_to;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label bookRoom_getPrecio;
        private System.Windows.Forms.Button bookpaga_Btn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboMetodoPago;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtTarjeta;
        public System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textbuscador;
    }
}
