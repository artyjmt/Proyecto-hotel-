﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionHotel
{
    internal class csConexion
    {
        // 🔹 Cadena de conexión fija (puedes moverla a App.config)

        private string cadena = @"Server=.\SQLEXPRESS;Database=SQLHotel;Trusted_Connection=True;";


        // 🔹 Conexión compartida (para Abrir() y Cerrar())

        private SqlConnection cn;

        public csConexion()
        {
            cn = new SqlConnection(cadena);
        }

        public void Abrir()
        {
            if (cn.State == ConnectionState.Closed)
            {
                cn.Open();
                Console.WriteLine(" Conexión abierta.");
            }
        }

        public void Cerrar()
        {
            if (cn.State == ConnectionState.Open)
            {
                cn.Close();
                Console.WriteLine(" Conexión cerrada.");
            }
        }

        public SqlConnection ObtenerConexion()
        {
            return cn;
        }
    }

}
