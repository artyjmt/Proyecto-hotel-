﻿using System;
using System.Data.SqlClient;

namespace GestionHotel
{
    internal class csCompraProductos
    {
        private csConexion conexion = new csConexion();
        public string PagoCarrito(int idProducto, int cantidadRestar, decimal monto)
        {
            try
            {
                conexion.Abrir();

                // Consultar stock actual
                string sqlSelect = "SELECT cantidad FROM ProductosVenta WHERE id_producto = @id";
                using (SqlCommand cmd = new SqlCommand(sqlSelect, conexion.ObtenerConexion()))
                {
                    cmd.Parameters.AddWithValue("@id", idProducto);
                    object result = cmd.ExecuteScalar();

                    if (result == null) return "Producto no encontrado.";

                    int stockActual = Convert.ToInt32(result);

                    if (stockActual < cantidadRestar)
                        return "No hay suficiente stock disponible.";

                    // Actualizar stock
                    string sqlUpdate = "UPDATE ProductosVenta SET cantidad = cantidad - @resta WHERE id_producto = @id";
                    using (SqlCommand cmd2 = new SqlCommand(sqlUpdate, conexion.ObtenerConexion()))
                    {
                        cmd2.Parameters.AddWithValue("@resta", cantidadRestar);
                        cmd2.Parameters.AddWithValue("@id", idProducto);
                        cmd2.ExecuteNonQuery();
                    }
                }

                return "OK";
            }
            catch (Exception ex)
            {
                return "Error: " + ex.Message;
            }
            finally
            {
                conexion.Cerrar();
            }
        }
    }

}
