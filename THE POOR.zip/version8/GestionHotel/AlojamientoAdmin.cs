﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace GestionHotel
{
    public partial class AlojamientoAdmin : UserControl
    {
        private csConexion conexion = new csConexion();
        private PanelAdministración panelAdmin;
        private csAlojamiento alojamiento = new csAlojamiento();

        public AlojamientoAdmin()
        {
            InitializeComponent();
            displayData();
        }

        public AlojamientoAdmin(PanelAdministración panel)
        {
            panelAdmin = panel;
            InitializeComponent();
        }


        public void RefreshData()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)RefreshData);
                return;
            }
        }

        public void displayData()
        {

            roomsData rData = new roomsData();
            List<roomsData> listD = rData.listRoomsData();
            dataGridView1.DataSource = listD;

        }
        public bool isEmpty()
        {
            if (string.IsNullOrEmpty(rooms_roomID.Text) || string.IsNullOrEmpty(rooms_roomName.Text)
                || rooms_type.SelectedIndex == -1 || string.IsNullOrEmpty(rooms_price.Text)
                || rooms_status.SelectedIndex == -1 || rooms_picture.Image == null)
            {
                return true;
            }
            return false;
        }
        private void rooms_addBtn_Click(object sender, EventArgs e)
        {
            if (isEmpty())
            {
                MessageBox.Show("Por favor rellena todos los espacios en blanco", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                alojamiento.Añadir(rooms_roomID.Text.Trim(), rooms_type.SelectedItem.ToString().Trim(), rooms_roomName.Text.Trim(), rooms_price.Text.Trim(), rooms_status.SelectedItem.ToString().Trim(), rooms_picture.ImageLocation);
                clearFields();
                displayData();
                MessageBox.Show("Habitación añadida correctamente", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void rooms_importBtn_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog file = new OpenFileDialog();
                string imagePath = "";
                file.Filter = "Image Files(*.jpg; *.jpeg; *.png)|*.jpg; *.jpeg; *.png";
                if (file.ShowDialog() == DialogResult.OK)
                {
                    imagePath = file.FileName;
                    rooms_picture.ImageLocation = imagePath;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al importar la imagen: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void rooms_uptadeBtn_Click(object sender, EventArgs e)
        {
            if (isEmpty())
            {
                MessageBox.Show("Por favor rellena todos los espacios en blanco", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {

                if (MessageBox.Show("¿Estás seguro de que quieres actualizar esta habitación:" + id + "?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)

                {
                    alojamiento.Editar(id, rooms_roomID.Text.Trim(), rooms_type.SelectedItem.ToString().Trim(), rooms_roomName.Text.Trim(), rooms_price.Text.Trim(), rooms_status.SelectedItem.ToString().Trim());
                    clearFields();
                    displayData();
                    MessageBox.Show("Habitación actualizada correctamente", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }

        }

        private void rooms_deleteBtn_Click(object sender, EventArgs e)
        {
            if (isEmpty())
            {
                MessageBox.Show("Por favor rellena todos los espacios en blanco", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {

                if (MessageBox.Show("¿Estás seguro de que quieres borrar esta habitación:" + id + "?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)

                {
                    alojamiento.Borrar(id);
                    clearFields();
                    displayData();
                    MessageBox.Show("Habitación borrrada correctamente", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private int id;
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                id = Convert.ToInt32(row.Cells[0].Value); // Assuming the first column is the ID
                rooms_roomID.Text = row.Cells[1].Value.ToString();
                rooms_type.SelectedItem = row.Cells[2].Value.ToString();
                rooms_roomName.Text = row.Cells[3].Value.ToString();
                rooms_price.Text = row.Cells[4].Value.ToString();
                rooms_status.SelectedItem = row.Cells[6].Value.ToString();

                // Assuming the image path is stored in the 5th column
                string imagePath = row.Cells[5].Value.ToString();
                if (File.Exists(imagePath))
                {

                    rooms_picture.ImageLocation = imagePath;
                }
            }
        }
        private void clearFields()
        {
            rooms_roomID.Text = "";
            rooms_roomName.Text = "";
            rooms_price.Text = "";
            rooms_type.SelectedIndex = -1;
            rooms_status.SelectedIndex = -1;
            rooms_picture.Image = null;
        }
        private void rooms_clearBtn_Click(object sender, EventArgs e)
        {
            clearFields();
        }

        private void rooms_price_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Bloquea el carácter
            }
        }

        private void rooms_picture_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}