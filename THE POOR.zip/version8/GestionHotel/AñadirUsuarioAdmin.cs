﻿using System;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;

namespace GestionHotel
{
    public partial class AñadirUsuarioAdmin : UserControl
    {
        private csConexion conexion = new csConexion();
        private csAñadirUsuario User = new csAñadirUsuario();

        public AñadirUsuarioAdmin()
        {
            InitializeComponent();

            displayData();
            dataGridView1.Refresh();


        }



        public void RefreshData()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)RefreshData);
                return;
            }
        }

        public void displayData()
        {
            userData uData = new userData();
            dataGridView1.DataSource = uData.listUserData();
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void AñadirUsuarioAdmin_Load(object sender, EventArgs e)
        {

        }

        private void addUser_addBtn_Click(object sender, EventArgs e)
        {

            // 🔹 Validar campos vacíos
            if (addUser_username.Text == "" || addUser_password.Text == "" ||
                addUser_role.SelectedIndex == -1 || addUser_status.SelectedIndex == -1 ||
                addUser_tipoIdentificacion.SelectedIndex == -1 || addUser_numIdentificacion.Text == "")
            {
                MessageBox.Show("Por favor rellena todos los espacios en blanco",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // le asigna variables a los campos de tipo y numero identificacion
            string tipo = addUser_tipoIdentificacion.SelectedItem.ToString();
            string numero = addUser_numIdentificacion.Text.Trim();

            // 🔹 Validación según tipo
            if (tipo == "Cédula")
            {
                if (numero.Length != 10 || !numero.All(char.IsDigit))
                {
                    MessageBox.Show("La cédula debe tener exactamente 10 dígitos numéricos",
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            else if (tipo == "RUC")
            {
                if (numero.Length != 13 || !numero.All(char.IsDigit))
                {
                    MessageBox.Show("El RUC debe tener exactamente 13 dígitos numéricos",
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            else if (tipo == "Pasaporte")
            {
                if (numero.Length < 8 || numero.Length > 9)
                {
                    MessageBox.Show("El pasaporte debe tener entre 8 y 9 caracteres alfanuméricos",
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            // 🔹 Validar si ya existe
            if (User.ExisteIdentificacion(tipo, numero))
            {
                MessageBox.Show("Ya existe un usuario registrado con este número de identificación",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // ✅ Si pasa la validación, se añade
            string usuarioNuevo = addUser_username.Text.Trim();

            User.Añadir(usuarioNuevo,
                        addUser_password.Text.Trim(),
                        addUser_role.SelectedItem.ToString(),
                        addUser_status.SelectedItem.ToString(),
                        tipo, numero);

            // 🔹 Refrescar campos y tabla
            clearFields();
            displayData();

            // 🔹 Refrescar ComboBox en HorarioLaboralAdmin
            foreach (Control ctrl in this.Parent.Controls)
            {
                if (ctrl is HorarioLaboralAdmin horario)
                {
                    horario.RefrescarEmpleados(usuarioNuevo); // ← selecciona directamente al nuevo usuario
                }
            }

            MessageBox.Show("Usuario añadido correctamente",
                "Mensaje informativo", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }


        private void clearFields()
        {
            addUser_username.Text = "";
            addUser_password.Text = "";
            addUser_role.SelectedIndex = -1;
            addUser_status.SelectedIndex = -1;
            addUser_tipoIdentificacion.SelectedIndex = -1; // limpia el comboBox
            addUser_numIdentificacion.Text = "";
        }

        private void addUser_clearBtn_Click(object sender, EventArgs e)
        {
            clearFields();
        }

        private void addUser_uptadeBtn_Click(object sender, EventArgs e)
        {

            if (addUser_username.Text == "" || addUser_password.Text == ""
        || addUser_role.SelectedIndex == -1 || addUser_status.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor rellena todos los espacios en blanco", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (getID == -1)
                {
                    MessageBox.Show("Por favor selecciona un usuario antes de editar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (MessageBox.Show("¿Seguro que quieres actualizar este usuario con ID " + getID + "?", "Actualizar usuario", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    User.Editar(getID,
                                addUser_username.Text.Trim(),
                                addUser_password.Text.Trim(),
                                addUser_role.SelectedItem.ToString(),
                                addUser_status.Text.Trim(),
                                addUser_tipoIdentificacion.SelectedItem.ToString(),
                                addUser_numIdentificacion.Text.Trim());

                    displayData();
                    clearFields();
                    getID = -1;
                    MessageBox.Show("Usuario actualizado correctamente", "Mensaje informativo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private int getID;


        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                getID = (int)row.Cells[0].Value; // ID
                addUser_username.Text = row.Cells[1].Value.ToString();
                addUser_password.Text = row.Cells[2].Value.ToString();
                addUser_role.Text = row.Cells[3].Value.ToString();
                addUser_status.Text = row.Cells[4].Value.ToString();
                addUser_tipoIdentificacion.Text = row.Cells[6].Value.ToString(); // tipo_identificacion
                addUser_numIdentificacion.Text = row.Cells[7].Value.ToString(); // numero_identificacion
            }
        }

        private void addUser_deleteBtn_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Seguro que quieres borrar este usuario?" + getID + "?", "Borrar a este usuario", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                User.Eliminar(addUser_username.Text.Trim());
                displayData();
                clearFields(); // Limpia los campos después de borrar
                getID = -1;    // Reinicia el ID
                MessageBox.Show("Usuario borrado correctamente", "Mensaje informativo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void addUser_numIdentificacion_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (addUser_tipoIdentificacion.SelectedItem == null) return;

            string tipo = addUser_tipoIdentificacion.SelectedItem.ToString();

            if (tipo == "Cédula")
            {
                addUser_numIdentificacion.MaxLength = 10; // Solo 10 dígitos
            }
            else if (tipo == "RUC")
            {
                addUser_numIdentificacion.MaxLength = 13; // Solo 13 dígitos
            }
            else if (tipo == "Pasaporte")
            {
                addUser_numIdentificacion.MaxLength = 9; // Generalmente 8 o 9
            }
        }
    }
}
