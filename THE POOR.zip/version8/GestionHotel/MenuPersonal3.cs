﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionHotel
{
    public partial class MenuPersonal3 : Form
    {
        public MenuPersonal3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panelAdministración1.Visible = false;
            reservarHotelEmpleado1.Visible = true;
            añadirClienteEmpleado1.Visible = false;
            comprasProductos1.Visible = false;

            PanelAdministración panelFrom = panelAdministración1 as PanelAdministración;
            if (panelFrom != null)
            {
                panelFrom.RefreshData();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            panelAdministración1.Visible = false;
            reservarHotelEmpleado1.Visible = true;
            añadirClienteEmpleado1.Visible = false;
            comprasProductos1.Visible = false;


            ReservarHotelEmpleado resFrom = reservarHotelEmpleado1 as ReservarHotelEmpleado;
            if (resFrom != null)
            {
                resFrom.RefreshData();
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            panelAdministración1.Visible = false;
            reservarHotelEmpleado1.Visible = false;
            añadirClienteEmpleado1.Visible = true;
            comprasProductos1.Visible = false;
            AñadirClienteEmpleado anafrom = añadirClienteEmpleado1 as AñadirClienteEmpleado;
            if (anafrom != null)
            {
                anafrom.RefreshData();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panelAdministración1.Visible = false;
            reservarHotelEmpleado1.Visible = false;
            añadirClienteEmpleado1.Visible = false;
            comprasProductos1.Visible = true;
            ComprasProductos comFrom = comprasProductos1 as ComprasProductos;
            if (comFrom != null)
            {
                comFrom.RefreshData();
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Seguro que quieres salir?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Form1 form1 = new Form1();
                form1.Show();
                this.Hide();
            }
        }
    }
}
