﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionHotel
{
    public partial class MenuPersonal : Form
    {
        // Instancias globales de tus UserControls
        public ReservarHotelEmpleado reservarUC = new ReservarHotelEmpleado();
        public AñadirClienteEmpleado anadirUC = new AñadirClienteEmpleado();

        public MenuPersonal()
        {

            InitializeComponent();

            reservarHotelEmpleado1.SetPanelAdministracion(panelAdministración1);
            comprasProductos1.SetPanelAdministracion(panelAdministración1);

            reservarHotelEmpleado1.SetPanelAdministracion(panelAdministración1);
            comprasProductos1.SetPanelAdministracion(panelAdministración1);

            // Conectar AñadirCliente con ReservarHotel
            añadirClienteEmpleado1.SetReservarHotelForm(reservarHotelEmpleado1);

        }
       

        private void MenuPersonal_Load(object sender, EventArgs e)
        {

        }


        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Seguro que quieres salir?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }


        private void panel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Seguro que quieres salir?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Form1 form1 = new Form1();
                form1.Show();
                this.Hide();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panelAdministración1.Visible = true;
            reservarHotelEmpleado1.Visible = false;
            clientesAdmin1.Visible = false;
            comprasProductos1.Visible = false;
            añadirClienteEmpleado1.Visible = false;


            PanelAdministración dashform = panelAdministración1 as PanelAdministración;
            if (dashform != null)
            {
                dashform.RefreshData();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            panelAdministración1.Visible = false;
            reservarHotelEmpleado1.Visible = true;
            clientesAdmin1.Visible = false;
            comprasProductos1.Visible = false;
            añadirClienteEmpleado1.Visible = false;


            ReservarHotelEmpleado resFrom = reservarHotelEmpleado1 as ReservarHotelEmpleado;
            if (resFrom != null)
            {
                resFrom.RefreshData();
            }
           
        }

        private void clientesAdmin1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            panelAdministración1.Visible = false;
            reservarHotelEmpleado1.Visible = false;
            clientesAdmin1.Visible = true;
            comprasProductos1.Visible = false;
            añadirClienteEmpleado1.Visible = false;


            ClientesAdmin adFrom = clientesAdmin1 as ClientesAdmin;
            if (adFrom != null)
            {
                adFrom.RefreshData();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

            panelAdministración1.Visible = false;
            reservarHotelEmpleado1.Visible = false;
            clientesAdmin1.Visible = false;
            comprasProductos1.Visible = true;
            añadirClienteEmpleado1.Visible = false;


            ComprasProductos cofrom = comprasProductos1 as ComprasProductos;
            if (cofrom != null)
            {
                cofrom.RefreshData();
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            panelAdministración1.Visible = false;
            reservarHotelEmpleado1.Visible = false;
            clientesAdmin1.Visible = false;
            comprasProductos1.Visible = false;
            añadirClienteEmpleado1.Visible = true;
             AñadirClienteEmpleado añafrom = añadirClienteEmpleado1 as AñadirClienteEmpleado;
            if (añafrom != null)
            {
                añafrom.RefreshData();
            }
            
        }

        // Cuando abras InfoCliente desde MenuPersonal:

    }
}
