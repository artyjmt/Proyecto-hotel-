﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionHotel
{
    internal class csReservaHotel
    {
        private csConexion conexion = new csConexion();

        public decimal Calculartotal(int days, decimal getPrice)
        {
            if (days <= 0)
            {
                MessageBox.Show("La fecha de salida debe ser posterior a la de entrada.",
                                "Error de fechas", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 0;
            }

            if (days > 365)
            {
                MessageBox.Show("No se permiten reservas mayores a 365 días.",
                                "Error de fechas", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 0;
            }

            if (getPrice <= 0)
            {
                MessageBox.Show("El precio de la habitación no es válido.",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 0;
            }

            return days * getPrice;
        }
    }
}
