﻿namespace GestionHotel
{
    partial class HorarioLaboralAdmin
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtIdentificacion = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnlimpiar = new System.Windows.Forms.Button();
            this.btnelim = new System.Windows.Forms.Button();
            this.btnedi = new System.Windows.Forms.Button();
            this.btnaña = new System.Windows.Forms.Button();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbEmpleado = new System.Windows.Forms.ComboBox();
            this.cmbHoraEntrada = new System.Windows.Forms.ComboBox();
            this.cmbHoraSalida = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.dataGridView2);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Location = new System.Drawing.Point(13, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(594, 650);
            this.panel1.TabIndex = 0;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(18, 41);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(560, 588);
            this.dataGridView2.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(15, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(188, 18);
            this.label8.TabIndex = 3;
            this.label8.Text = "Horario de empleados:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.cmbHoraSalida);
            this.panel2.Controls.Add(this.cmbHoraEntrada);
            this.panel2.Controls.Add(this.cmbEmpleado);
            this.panel2.Controls.Add(this.txtIdentificacion);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.btnlimpiar);
            this.panel2.Controls.Add(this.btnelim);
            this.panel2.Controls.Add(this.btnedi);
            this.panel2.Controls.Add(this.btnaña);
            this.panel2.Controls.Add(this.checkedListBox1);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(629, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(325, 650);
            this.panel2.TabIndex = 1;
            // 
            // txtIdentificacion
            // 
            this.txtIdentificacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIdentificacion.Location = new System.Drawing.Point(173, 83);
            this.txtIdentificacion.Name = "txtIdentificacion";
            this.txtIdentificacion.ReadOnly = true;
            this.txtIdentificacion.Size = new System.Drawing.Size(119, 26);
            this.txtIdentificacion.TabIndex = 33;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(60, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 20);
            this.label1.TabIndex = 32;
            this.label1.Text = "Idenificacion:";
            // 
            // btnlimpiar
            // 
            this.btnlimpiar.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnlimpiar.FlatAppearance.BorderSize = 0;
            this.btnlimpiar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.RoyalBlue;
            this.btnlimpiar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue;
            this.btnlimpiar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnlimpiar.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlimpiar.ForeColor = System.Drawing.Color.White;
            this.btnlimpiar.Location = new System.Drawing.Point(42, 509);
            this.btnlimpiar.Name = "btnlimpiar";
            this.btnlimpiar.Size = new System.Drawing.Size(250, 41);
            this.btnlimpiar.TabIndex = 30;
            this.btnlimpiar.Text = "Limpíar Horario";
            this.btnlimpiar.UseVisualStyleBackColor = false;
            // 
            // btnelim
            // 
            this.btnelim.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnelim.FlatAppearance.BorderSize = 0;
            this.btnelim.FlatAppearance.MouseDownBackColor = System.Drawing.Color.RoyalBlue;
            this.btnelim.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue;
            this.btnelim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnelim.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnelim.ForeColor = System.Drawing.Color.White;
            this.btnelim.Location = new System.Drawing.Point(42, 456);
            this.btnelim.Name = "btnelim";
            this.btnelim.Size = new System.Drawing.Size(250, 41);
            this.btnelim.TabIndex = 29;
            this.btnelim.Text = "Eliminar Horario";
            this.btnelim.UseVisualStyleBackColor = false;
            // 
            // btnedi
            // 
            this.btnedi.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnedi.FlatAppearance.BorderSize = 0;
            this.btnedi.FlatAppearance.MouseDownBackColor = System.Drawing.Color.RoyalBlue;
            this.btnedi.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue;
            this.btnedi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnedi.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnedi.ForeColor = System.Drawing.Color.White;
            this.btnedi.Location = new System.Drawing.Point(42, 401);
            this.btnedi.Name = "btnedi";
            this.btnedi.Size = new System.Drawing.Size(250, 41);
            this.btnedi.TabIndex = 28;
            this.btnedi.Text = "Editar Horario";
            this.btnedi.UseVisualStyleBackColor = false;
            // 
            // btnaña
            // 
            this.btnaña.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnaña.FlatAppearance.BorderSize = 0;
            this.btnaña.FlatAppearance.MouseDownBackColor = System.Drawing.Color.RoyalBlue;
            this.btnaña.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue;
            this.btnaña.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnaña.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaña.ForeColor = System.Drawing.Color.White;
            this.btnaña.Location = new System.Drawing.Point(42, 348);
            this.btnaña.Name = "btnaña";
            this.btnaña.Size = new System.Drawing.Size(250, 41);
            this.btnaña.TabIndex = 27;
            this.btnaña.Text = "Añadir Horario";
            this.btnaña.UseVisualStyleBackColor = false;
            this.btnaña.Click += new System.EventHandler(this.btnaña_Click);
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Items.AddRange(new object[] {
            "Lunes",
            "Martes",
            "Miercoles",
            "Jueves",
            "Viernes",
            "Sabado",
            "Domingo"});
            this.checkedListBox1.Location = new System.Drawing.Point(173, 126);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(92, 109);
            this.checkedListBox1.TabIndex = 22;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(18, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(194, 18);
            this.label7.TabIndex = 3;
            this.label7.Text = "Definir Horario Laboral:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(49, 300);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(115, 20);
            this.label6.TabIndex = 20;
            this.label6.Text = "Hora de salida:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(78, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 20);
            this.label2.TabIndex = 14;
            this.label2.Text = "Empleado:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(35, 255);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(129, 20);
            this.label5.TabIndex = 18;
            this.label5.Text = "Hora de entrada:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(42, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 20);
            this.label4.TabIndex = 16;
            this.label4.Text = "Dias de trabajo:";
            // 
            // cmbEmpleado
            // 
            this.cmbEmpleado.FormattingEnabled = true;
            this.cmbEmpleado.Location = new System.Drawing.Point(169, 46);
            this.cmbEmpleado.Name = "cmbEmpleado";
            this.cmbEmpleado.Size = new System.Drawing.Size(121, 21);
            this.cmbEmpleado.TabIndex = 34;
            this.cmbEmpleado.SelectedIndexChanged += new System.EventHandler(this.cmbEmpleado_SelectedIndexChanged);
            // 
            // cmbHoraEntrada
            // 
            this.cmbHoraEntrada.FormattingEnabled = true;
            this.cmbHoraEntrada.Items.AddRange(new object[] {
            "00:00 AM",
            "0:30 AM",
            "1:00 AM",
            "1:30 AM",
            "2:00 AM",
            "2:30 AM",
            "3:00 AM",
            "3:30 AM",
            "4:00 AM",
            "4:30 AM",
            "5:00 AM",
            "5:30 AM",
            "6:00 AM",
            "6:30 AM",
            "7:00 AM",
            "7:30 AM",
            "8:00 AM",
            "8:30 AM",
            "9:00 AM",
            "9:30 AM",
            "10:00 AM",
            "10:30 AM",
            "11:00 AM",
            "11:30 AM",
            "12:00 PM",
            "12:30 PM",
            "13:00 PM",
            "13:30 PM",
            "14:00 PM",
            "14:30 PM",
            "15:00 PM",
            "15:30 PM",
            "16:00 PM",
            "16:30 PM",
            "17:00 PM",
            "17:30 PM",
            "18:00 PM",
            "18:30 PM",
            "19:00 PM",
            "19:30 PM",
            "20:00 PM",
            "20:30 PM",
            "21:00 PM",
            "21:30 PM",
            "22:00 PM",
            "22:30 PM",
            "23:00 PM",
            "23:30 PM"});
            this.cmbHoraEntrada.Location = new System.Drawing.Point(169, 257);
            this.cmbHoraEntrada.Name = "cmbHoraEntrada";
            this.cmbHoraEntrada.Size = new System.Drawing.Size(123, 21);
            this.cmbHoraEntrada.TabIndex = 36;
            // 
            // cmbHoraSalida
            // 
            this.cmbHoraSalida.FormattingEnabled = true;
            this.cmbHoraSalida.Items.AddRange(new object[] {
            "00:00 AM",
            "0:30 AM",
            "1:00 AM",
            "1:30 AM",
            "2:00 AM",
            "2:30 AM",
            "3:00 AM",
            "3:30 AM",
            "4:00 AM",
            "4:30 AM",
            "5:00 AM",
            "5:30 AM",
            "6:00 AM",
            "6:30 AM",
            "7:00 AM",
            "7:30 AM",
            "8:00 AM",
            "8:30 AM",
            "9:00 AM",
            "9:30 AM",
            "10:00 AM",
            "10:30 AM",
            "11:00 AM",
            "11:30 AM",
            "12:00 PM",
            "12:30 PM",
            "13:00 PM",
            "13:30 PM",
            "14:00 PM",
            "14:30 PM",
            "15:00 PM",
            "15:30 PM",
            "16:00 PM",
            "16:30 PM",
            "17:00 PM",
            "17:30 PM",
            "18:00 PM",
            "18:30 PM",
            "19:00 PM",
            "19:30 PM",
            "20:00 PM",
            "20:30 PM",
            "21:00 PM",
            "21:30 PM",
            "22:00 PM",
            "22:30 PM",
            "23:00 PM",
            "23:30 PM"});
            this.cmbHoraSalida.Location = new System.Drawing.Point(167, 302);
            this.cmbHoraSalida.Name = "cmbHoraSalida";
            this.cmbHoraSalida.Size = new System.Drawing.Size(123, 21);
            this.cmbHoraSalida.TabIndex = 37;
            // 
            // HorarioLaboralAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "HorarioLaboralAdmin";
            this.Size = new System.Drawing.Size(967, 676);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.Button btnaña;
        private System.Windows.Forms.Button btnlimpiar;
        private System.Windows.Forms.Button btnelim;
        private System.Windows.Forms.Button btnedi;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtIdentificacion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbEmpleado;
        private System.Windows.Forms.ComboBox cmbHoraEntrada;
        private System.Windows.Forms.ComboBox cmbHoraSalida;
    }
}
