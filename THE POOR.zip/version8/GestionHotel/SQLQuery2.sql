﻿
SELECT * FROM customer

SELECT 
    book_id AS [ID Reserva],
    full_name AS [Nombre Completo],
    email AS [Correo Electrónico],
    contact AS [Número de Contacto],
    gender AS [Género],
    address AS [Dirección],
    price AS [Precio],
    status_payment AS [Estado de Pago],
    status AS [Estado],
    date_from AS [Desde],
    date_to AS [Hasta],
    date_register AS [Fecha de Registro]
FROM customer;