﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionHotel
{
    public partial class MenuAdmin : Form
    {
        public MenuAdmin()
        {
            InitializeComponent();
            this.AutoSize = true;
            this.AutoSizeMode = AutoSizeMode.GrowAndShrink;

            // Enlaza el panel administrativo con el control de reservas
          
            // Enlaza el panel administrativo con el control de reservas
            
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void alojamientoAdmin1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("¿Seguro que quieres salir?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
         
        }

        private void login_btn_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("¿Seguro que quieres cerrar sesión?", "Cerrar sesión", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Hide(); // Hide the current form
                Form1 loginForm = new Form1(); // Create a new instance of the login form
                loginForm.Show(); // Show the login form
            }
        }

        private void añadirUsuarioAdmin1_Load(object sender, EventArgs e)
        {

        }

        private void dashboard_btn_Click(object sender, EventArgs e)
        {
            pagosAdmin1.Visible = false;
            inventarioAdmin1.Visible = false;
            panelAdministración1.Visible = true;
            añadirUsuarioAdmin1.Visible = false;
            alojamientoAdmin1.Visible = false;
            clientesAdmin1.Visible = false;
            horarioLaboralAdmin1.Visible = false;

            PanelAdministración dashform = panelAdministración1 as PanelAdministración ;
            if (dashform != null)
            {
                dashform.RefreshData();
            }

        }

        private void addUser_btn_Click(object sender, EventArgs e)
        {
            pagosAdmin1.Visible = false;
            horarioLaboralAdmin1.Visible = false;
            panelAdministración1.Visible = false;
            añadirUsuarioAdmin1.Visible = true;
            alojamientoAdmin1.Visible = false;
            clientesAdmin1.Visible = false;
            inventarioAdmin1.Visible = false;

            AñadirUsuarioAdmin addUserForm = añadirUsuarioAdmin1 as AñadirUsuarioAdmin;
            if (addUserForm != null)
            {
                addUserForm.RefreshData();
            }
        }

        private void rooms_btn_Click(object sender, EventArgs e)
        {
            pagosAdmin1.Visible = false;
            horarioLaboralAdmin1.Visible =false;
            panelAdministración1.Visible = false;
            añadirUsuarioAdmin1.Visible = false;
            alojamientoAdmin1.Visible = true;
            clientesAdmin1.Visible = false;
            inventarioAdmin1.Visible = false;

            AlojamientoAdmin roomsForm = alojamientoAdmin1 as AlojamientoAdmin;
            if (roomsForm != null)
            {
                roomsForm.RefreshData();
            }
        }

        private void customers_btn_Click(object sender, EventArgs e)
        {
            pagosAdmin1.Visible = false;
            horarioLaboralAdmin1.Visible = false;
            panelAdministración1.Visible = false;
            añadirUsuarioAdmin1.Visible = false;
            alojamientoAdmin1.Visible = false;
            clientesAdmin1.Visible = true;
            inventarioAdmin1.Visible = false;
            ClientesAdmin adFrom = clientesAdmin1 as ClientesAdmin;
            if (adFrom != null)
            {
                adFrom.RefreshData();
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            pagosAdmin1.Visible = false;
            horarioLaboralAdmin1.Visible = true;
            panelAdministración1.Visible = false;
            añadirUsuarioAdmin1.Visible = false;
            alojamientoAdmin1.Visible = false;
            clientesAdmin1.Visible = false;
            inventarioAdmin1.Visible = false;

            // Verificar que el panel sea del tipo HorarioLaboralAdmin
            HorarioLaboralAdmin horario = horarioLaboralAdmin1 as HorarioLaboralAdmin;
            if (horario != null)
            {
                horario.RefreshData();
            }
        }


        private void inventarioAdmin1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            pagosAdmin1.Visible = false;
            horarioLaboralAdmin1.Visible = false;
            panelAdministración1.Visible = false;
            añadirUsuarioAdmin1.Visible = false;
            alojamientoAdmin1.Visible = false;
            clientesAdmin1.Visible = false;
            inventarioAdmin1.Visible = true;

            // Verificar que el panel sea del tipo InventarioAdmin
            InventarioAdmin inventario = inventarioAdmin1 as InventarioAdmin;
            if (inventario != null)
            {
                inventario.RefreshData();
            }
        }

        private void horarioLaboralAdmin1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            pagosAdmin1.Visible = true;
            horarioLaboralAdmin1.Visible = false;
            inventarioAdmin1.Visible = false;
            panelAdministración1.Visible = false;
            añadirUsuarioAdmin1.Visible = false;
            alojamientoAdmin1.Visible = false;
            clientesAdmin1.Visible = false;
            PagosAdmin pagos = pagosAdmin1 as PagosAdmin;
            if (pagos != null)
            {
                pagos.RefreshData();
            }
        }
    }
}
