﻿CREATE TABLE users
(
id INT PRIMARY KEY IDENTITY(1,1),
username VARCHAR (MAX) NULL,
password VARCHAR (MAX) NULL,
role VARCHAR (MAX) NULL,
status VARCHAR (MAX) NULL,
date_register DATE NULL
)


SELECT * FROM users

INSERT INTO users (username, password, role, status, date_register) values ('admin', 'admin123','Administrador','Activo','2025-08-03');


CREATE TABLE room
(
    id INT PRIMARY KEY IDENTITY(1,1),
    room_id VARCHAR(MAX) NULL,
    type VARCHAR(MAX) NULL,
   room_name VARCHAR(MAX) NULL,
   price FLOAT NULL,
   image_path VARCHAR(max) NULL,
   status VARCHAR (MAX) NULL,
   date_register DATE NULL,
   date_update DATE NULL,
   date_delete DATE NULL,
)

SELECT * FROM room

SELECT room_id FROM room

SELECT * FROM room WHERE date_delete IS NULL

SELECT * FROM users

CREATE TABLE customer
(
   id INT PRIMARY KEY IDENTITY(1,1),
   book_id VARCHAR(MAX) NULL,
   room_id VARCHAR(MAX) NULL,
   full_name VARCHAR(MAX) NULL,
   email VARCHAR(MAX) NULL,
   contact VARCHAR(MAX) NULL,
   gender VARCHAR(MAX) NULL,
   address VARCHAR(MAX) NULL,
   price DECIMAL NULL,
   status_payment VARCHAR(MAX) NULL,
   status VARCHAR(MAX) NULL,
   date_from DATE NULL,
   date_to DATE NULL,
   date_register DATE NULL
)

SELECT * FROM customer

SELECT COUNT(id) FROM customer



CREATE TABLE Productos (
    id_producto INT IDENTITY(1,1) PRIMARY KEY,
    nombre NVARCHAR(100) NOT NULL UNIQUE
);


CREATE TABLE Inventario (
    id_inventario INT IDENTITY(1,1) PRIMARY KEY,
    id_producto INT NOT NULL,
    cantidad INT NOT NULL,
    fecha_registro DATETIME NOT NULL DEFAULT GETDATE(),
    FOREIGN KEY (id_producto) REFERENCES Productos(id_producto)
);


CREATE TABLE ProductosVenta (
    id_venta INT IDENTITY(1,1) PRIMARY KEY,
    id_producto INT NOT NULL,
    cantidad INT NOT NULL,
    precio DECIMAL(10,2) NOT NULL,
    fecha_registro DATETIME NOT NULL DEFAULT GETDATE(),
    image1_path NVARCHAR(255) NULL,
    FOREIGN KEY (id_producto) REFERENCES Productos(id_producto)
);

select * from Productos 
select * from Inventario
select * from ProductosVenta