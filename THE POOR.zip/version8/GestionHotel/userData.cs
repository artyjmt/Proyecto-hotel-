﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace GestionHotel
{
    internal class userData
    {
        private csConexion conexion = new csConexion();
        public int ID { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
        public string Status { get; set; }
        public string Datereg { get; set; }
        public string TipoIdentificacion { get; set; }
        public string NumeroIdentificacion { get; set; }
        public List<userData> listUserData()
        {
            List<userData> listData = new List<userData>();
            try
            { conexion.Abrir();
                string selecData = "SELECT * FROM users";
                using (SqlCommand cmd = new SqlCommand(selecData, conexion.ObtenerConexion()))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    {
                        while (reader.Read())
                        {
                            userData uData = new userData();

                            uData.ID = (int)reader["id"];
                            uData.Username = reader["username"].ToString();
                            uData.Password = reader["password"].ToString();
                            uData.Role = reader["role"].ToString();
                            uData.Status = reader["status"].ToString();
                            uData.Datereg = reader["date_register"].ToString();
                            uData.TipoIdentificacion = reader["tipo_identificacion"].ToString();
                            uData.NumeroIdentificacion = reader["numero_identificacion"].ToString();

                            listData.Add(uData);

                        }

                    }
                }
                return listData;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al conectar con la base de datos: " + ex.Message);
                return listData;
            }
            finally
            {
                conexion.Cerrar();
            }

        }
    }
}
