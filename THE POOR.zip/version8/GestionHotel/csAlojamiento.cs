﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace GestionHotel
{
    internal class csAlojamiento
    {
        private csConexion conexion = new csConexion();
        public void Añadir(string roomID, string type, string roomName, string price, string status, string sourceImagePath)
        {
            try
            {
                conexion.Abrir();
                // 1️⃣ Validar que el RoomID no exista
                string Query1 = "SELECT room_id FROM room WHERE room_id=@roomID";
                using (SqlCommand checkCmd = new SqlCommand(Query1, conexion.ObtenerConexion()))
                {
                    checkCmd.Parameters.AddWithValue("@roomID", roomID);
                    SqlDataAdapter sda = new SqlDataAdapter(checkCmd);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    if (dt.Rows.Count > 0)
                        throw new Exception($"El ID de habitación '{roomID}' ya existe. Por favor, elige otro.");
                }

                // 2️⃣ Manejo de la imagen
                string path = Path.Combine(@"C:\Users\Usuario\Downloads", roomID + ".jpg");
                string directoryPath = Path.GetDirectoryName(path);
                if (!Directory.Exists(directoryPath))
                    Directory.CreateDirectory(directoryPath);
                File.Copy(sourceImagePath, path, true);

                // 3️⃣ Insertar en la base de datos
                string insertData = @"INSERT INTO room (room_id, type, room_name, price, image_path, status, date_register) 
                                      VALUES (@roomID, @type, @roomName, @price, @path, @status, @date_reg)";
                using (SqlCommand cmd = new SqlCommand(insertData, conexion.ObtenerConexion()))
                {
                    cmd.Parameters.AddWithValue("@roomID", roomID.Trim());
                    cmd.Parameters.AddWithValue("@type", type.Trim());
                    cmd.Parameters.AddWithValue("@roomName", roomName.Trim());
                    cmd.Parameters.AddWithValue("@price", price.Trim());
                    cmd.Parameters.AddWithValue("@path", path);
                    cmd.Parameters.AddWithValue("@status", status.Trim());
                    cmd.Parameters.AddWithValue("@date_reg", DateTime.Now);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al añadir la habitación: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }

        public void Editar(int id, string roomID, string type, string roomName, string price, string status)
        {
            try
            {
                conexion.Abrir();

                string updateQuery = @"UPDATE room SET room_id = @roomID, type = @type, room_name = @roomName, price = @price,  
                                       status = @status, date_update = @update WHERE id = @id";

                using (SqlCommand cmd = new SqlCommand(updateQuery, conexion.ObtenerConexion()))
                {
                    cmd.Parameters.AddWithValue("@roomID", roomID.Trim());
                    cmd.Parameters.AddWithValue("@type", type.Trim());
                    cmd.Parameters.AddWithValue("@roomName", roomName.Trim());
                    cmd.Parameters.AddWithValue("@price", price.Trim());
                    cmd.Parameters.AddWithValue("@status", status.Trim());
                    cmd.Parameters.AddWithValue("@update", DateTime.Now);
                    cmd.Parameters.AddWithValue("@id", id);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al editar la habitación: " + ex.Message,
                  "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }
        public void Borrar(int id)
        {
            try
            {
                conexion.Abrir();
                string deleteQuery = "DELETE FROM room WHERE id = @id";
                using (SqlCommand cmd = new SqlCommand(deleteQuery, conexion.ObtenerConexion()))
                {
                    cmd.Parameters.AddWithValue("@delete", DateTime.Now);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al borrar la habitación: " + ex.Message,
                      "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexion.Cerrar();
            }
        }
    }
}
