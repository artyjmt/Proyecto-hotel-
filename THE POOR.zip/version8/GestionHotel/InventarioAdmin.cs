﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;


namespace GestionHotel
{
    public partial class InventarioAdmin : UserControl
    {
        private csConexion conexion = new csConexion();
        private csInventario inventario = new csInventario();

        public InventarioAdmin()
        {
            InitializeComponent();
            dataGridView1.CellClick += dataGridView1_CellClick;
            dataGridView2.CellClick += dataGridView2_CellClick;

            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.AllowUserToAddRows = false;

            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView2.AllowUserToAddRows = false;

        }
        public void RefreshData()
        {
            displayData();
            displayProductosVenta();
        }

        public void ClearFields()
        {
            textProducto.Text = "";
            textCantidad.Text = "";
            textproducto2.Text = "";
            textcantidad2.Text = "";
            textprecio.Text = "";
            productosVenta_picture.Image = null;
            // Si tienes más campos, límpialos aquí
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        public void displayData()
        {
            conexion.Abrir();
            //refrescar la tabla de inventario
            string query = @"SELECT i.id_inventario AS ID_Inventario, 
                        p.nombre AS Producto, 
                        i.cantidad AS Cantidad, 
                        i.fecha_registro AS Fecha
                 FROM Inventario i
                 INNER JOIN Productos p ON i.id_producto = p.id_producto";

            SqlDataAdapter da = new SqlDataAdapter(query, conexion.ObtenerConexion());
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            // 👉 Ocultar la columna ID después de llenar el DataGridView
            if (dataGridView1.Columns.Contains("ID_Inventario"))
                dataGridView1.Columns["ID_Inventario"].Visible = false;
        }




        public void displayProductosVenta()
        {
            try
            {
                conexion.Abrir();
                // Consulta para obtener nombre del producto, cantidad, precio, fecha de registro e imagen de ProductosVenta
                string query = @"SELECT pv.id_venta AS ID_Venta, 
                            p.nombre AS Producto, 
                            pv.cantidad AS Cantidad, 
                            pv.precio AS Precio, 
                            pv.fecha_registro AS Fecha,
                            pv.image1_path AS Imagen           
                     FROM ProductosVenta pv
                     INNER JOIN Productos p ON pv.id_producto = p.id_producto";

                using (SqlDataAdapter adapter = new SqlDataAdapter(query, conexion.ObtenerConexion()))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridView2.DataSource = dt; // Muestra todos los datos, incluida la ruta de la imagen
                     // 👉 Ocultar la columna ID después de llenar el DataGridView
                    if (dataGridView2.Columns.Contains("ID_Venta"))
                        dataGridView2.Columns["ID_Venta"].Visible = false;
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error de conexión: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        // añadir inventario
        private void button1_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(textProducto.Text) || string.IsNullOrWhiteSpace(textCantidad.Text))
            {
                MessageBox.Show("Por favor rellena todos los espacios en blanco", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                inventario.AñadirInventario(textProducto.Text, textCantidad.Text);
                displayData();
                ClearFields();
                MessageBox.Show("Producto añadido correctamente al Inventario", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        //boton añadir producto a ventas 
        private void button8_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(textproducto2.Text) ||
                 string.IsNullOrWhiteSpace(textcantidad2.Text) ||
                 string.IsNullOrWhiteSpace(textprecio.Text) ||
                productosVenta_picture.ImageLocation == null)
            {
                MessageBox.Show("Por favor rellena todos los espacios en blanco y selecciona una imagen",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                inventario.AañadirProductosVenta(textproducto2.Text, textcantidad2.Text, textprecio.Text, productosVenta_picture.ImageLocation);
                MessageBox.Show("Producto añadido correctamente a Ventas con imagen",
                       "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                displayProductosVenta();
                ClearFields();
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            RefreshData();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog file = new OpenFileDialog();
                file.Filter = "Image Files(*.jpg; *.jpeg; *.png)|*.jpg; *.jpeg; *.png";
                if (file.ShowDialog() == DialogResult.OK)
                {
                    productosVenta_picture.ImageLocation = file.FileName;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al importar la imagen: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textProducto.Text = row.Cells["Producto"].Value?.ToString();
                textCantidad.Text = row.Cells["Cantidad"].Value?.ToString();

                if (row.Cells["ID_Inventario"].Value != null)
                    selectedInventarioId = Convert.ToInt32(row.Cells["ID_Inventario"].Value);
            }
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView2.Rows[e.RowIndex];
                textproducto2.Text = row.Cells["Producto"].Value?.ToString();
                textcantidad2.Text = row.Cells["Cantidad"].Value?.ToString();
                textprecio.Text = row.Cells["Precio"].Value?.ToString();

                if (row.Cells["ID_Venta"].Value != null)
                    selectedVentaId = Convert.ToInt32(row.Cells["ID_Venta"].Value);

                var imagePath = row.Cells["Imagen"].Value?.ToString();
                if (!string.IsNullOrEmpty(imagePath) && System.IO.File.Exists(imagePath))
                {
                    productosVenta_picture.ImageLocation = imagePath;
                }
                else
                {
                    productosVenta_picture.Image = null;
                }
            }
        }

        private void btneditar_Click(object sender, EventArgs e)
        {
            if (selectedInventarioId == -1 && selectedVentaId == -1)
            {
                MessageBox.Show("Seleccione un registro primero", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            inventario.EditarProductosVenta2(selectedInventarioId, selectedVentaId, textproducto2.Text, textcantidad2.Text, textprecio.Text);
            displayData();
            displayProductosVenta();
            selectedInventarioId = -1;
            selectedVentaId = -1;
            MessageBox.Show("Registro actualizado correctamente");
        }

        private int selectedInventarioId = -1;
        private int selectedVentaId = -1;

        private void btneliminar_Click(object sender, EventArgs e)
        {

            if (selectedInventarioId == -1 && selectedVentaId == -1)
            {
                MessageBox.Show("Seleccione un registro primero", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult dr = MessageBox.Show("¿Seguro que desea eliminar el registro?","Confirmar",MessageBoxButtons.YesNo,MessageBoxIcon.Question);

            if (dr == DialogResult.Yes)
            {

                inventario.EliminarProductosVenta2(selectedInventarioId, selectedVentaId);
                MessageBox.Show("Registro eliminado de Inventario y ventas");
                displayData();
                displayProductosVenta();
                selectedInventarioId = -1;
                selectedVentaId = -1;
                ClearFields();
            }
        }

        private void InventarioAdmin_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (selectedInventarioId == -1 && selectedVentaId == -1)
            {
                MessageBox.Show("Seleccione un registro primero", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult dr = MessageBox.Show("¿Seguro que desea eliminar el registro y su producto del catálogo?","Confirmar",MessageBoxButtons.YesNo,MessageBoxIcon.Question);

            if (dr == DialogResult.Yes)
            {
                inventario.EliminarRegistroCompleto(selectedInventarioId, selectedVentaId);
                displayData();
                displayProductosVenta();
                selectedInventarioId = -1;
                selectedVentaId = -1;
                ClearFields();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (selectedInventarioId == -1)
            {
                MessageBox.Show("Seleccione un registro primero", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(textProducto.Text) || string.IsNullOrWhiteSpace(textCantidad.Text))
            {
                MessageBox.Show("Por favor rellena todos los campos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                inventario.EditarInventario(selectedInventarioId, textProducto.Text, textCantidad.Text);
                displayData();
                ClearFields();
                selectedInventarioId = -1;
            }
        }
    }
}
